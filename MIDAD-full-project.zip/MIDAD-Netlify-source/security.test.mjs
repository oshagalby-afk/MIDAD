import test from 'node:test';
import assert from 'node:assert/strict';
import { once } from 'node:events';
import { randomUUID } from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createMidadServer } from './server.mjs';
import { validateLocalFile, sanitizeLocalFileName } from './file-policy.mjs';

function mockFile(name, content, type = 'application/octet-stream') {
  const blob = new Blob([content], { type });
  Object.defineProperties(blob, { name: { value: name }, slice: { value: Blob.prototype.slice.bind(blob) } });
  return blob;
}
async function startTestServer(t) {
  const dataDir=fs.mkdtempSync(path.join(os.tmpdir(),'midad-test-'));
  const server=createMidadServer({dataDir});
  server.listen(0,'127.0.0.1'); await once(server,'listening');
  t.after(async()=>{ const closed=new Promise(resolve=>server.close(resolve));server.closeAllConnections();await closed;fs.rmSync(dataDir,{recursive:true,force:true}); });
  return { server, base:`http://127.0.0.1:${server.address().port}`, dataDir };
}
async function register(base, email=randomUUID()+'@example.invalid', username=`test-${randomUUID().slice(0,8)}`) {
  const response=await fetch(base+'/api/auth/register',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email,username,password:'test-only-password-This-is-not-real-22',displayName:'MIDAD Test'})});
  const body=await response.json();
  return {response,body,cookie:response.headers.get('set-cookie')?.split(';')[0]||''};
}

test('local file policy accepts signed PDFs and previewable images', async () => {
  assert.deepEqual(await validateLocalFile(mockFile('lesson.pdf', '%PDF-1.7\n')), { ok: true, previewKind: 'pdf' });
  assert.deepEqual(await validateLocalFile(mockFile('cover.png', new Uint8Array([137,80,78,71,13,10,26,10]))), { ok: true, previewKind: 'image' });
  assert.deepEqual(await validateLocalFile(mockFile('notes.txt', 'Study notes')), { ok: true, previewKind: 'text' });
});

test('local file policy rejects active, mismatched, empty, oversized and quota-exceeding files', async () => {
  assert.equal((await validateLocalFile(mockFile('payload.svg', '<svg/>'))).reason, 'active_type');
  assert.equal((await validateLocalFile(mockFile('fake.pdf', 'not a PDF'))).reason, 'signature');
  assert.equal((await validateLocalFile(mockFile('empty.txt', ''))).reason, 'empty');
  assert.equal((await validateLocalFile(mockFile('notes.txt', 'hello'), 4)).reason, 'quota');
  assert.equal((await validateLocalFile(mockFile('large.mp4', new Uint8Array(50 * 1024 * 1024 + 1)))).reason, 'too_large');
});

test('filename sanitizer removes path separators and control characters', () => {
  assert.equal(sanitizeLocalFileName('../private\\notes\u0000.txt'), '_private_notes.txt');
});

test('server serves only the application shell and applies security headers', async t => {
  const {base}=await startTestServer(t);
  const page=await fetch(base+'/');
  assert.equal(page.status,200);assert.match(page.headers.get('content-type'),/text\/html/);
  assert.equal(page.headers.get('x-content-type-options'),'nosniff');assert.equal(page.headers.get('x-frame-options'),'DENY');
  assert.match(page.headers.get('content-security-policy'),/default-src 'self'/);assert.equal(page.headers.get('cache-control'),'no-store');
  assert.equal(page.headers.get('access-control-allow-origin'),null);assert.match(await page.text(),/MIDAD/);
  const oldProxy=process.env.MIDAD_TRUST_PROXY;
  try{
    process.env.MIDAD_TRUST_PROXY='false';
    const spoofedHttps=await fetch(base+'/',{headers:{'x-forwarded-proto':'https'}});assert.equal(spoofedHttps.headers.get('strict-transport-security'),null);
    process.env.MIDAD_TRUST_PROXY='true';
    const trustedHttps=await fetch(base+'/',{headers:{'x-forwarded-proto':'https'}});assert.match(trustedHttps.headers.get('strict-transport-security'),/max-age=31536000/);
  }finally{if(oldProxy===undefined)delete process.env.MIDAD_TRUST_PROXY;else process.env.MIDAD_TRUST_PROXY=oldProxy;}
  assert.equal((await fetch(base+'/api/users')).status,401);
  assert.equal((await fetch(base+'/../../etc/passwd')).status,404);
  assert.equal((await fetch(base+'/%2e%2e/etc/passwd')).status,404);
  assert.equal((await fetch(base+'/.env')).status,404);
  const mutation=await fetch(base+'/app.js',{method:'POST'});assert.equal(mutation.status,405);assert.equal(mutation.headers.get('allow'),'GET, HEAD');
  assert.equal((await fetch(base+'/app.js',{method:'OPTIONS'})).status,405);
});

test('registration creates a real session; CSRF, owner-scoped data and role checks are enforced', async t => {
  const {base,server}=await startTestServer(t);
  const userEmail=randomUUID()+'@example.invalid';const user=await register(base,userEmail,'A132008');
  assert.equal(user.response.status,201);assert.equal(user.body.user.role,'student');assert.equal(user.body.user.username,'A132008');assert.equal(user.body.emailVerified,false);
  const usernameLogin=await fetch(base+'/api/auth/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({identifier:'a132008',password:'test-only-password-This-is-not-real-22'})});
  assert.equal(usernameLogin.status,200);assert.equal((await usernameLogin.json()).user.username,'A132008');
  const duplicateUsernameEmail=randomUUID()+'@example.invalid';const duplicateUsername=await fetch(base+'/api/auth/register',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email:duplicateUsernameEmail,username:'a132008',password:'test-only-password-This-is-not-real-22',displayName:'Another Test'})});
  assert.equal(duplicateUsername.status,409);assert.equal((await duplicateUsername.json()).error,'username_taken');
  assert.equal(server.midadDb.prepare('SELECT id FROM users WHERE email=?').get(duplicateUsernameEmail),undefined);
  assert.ok(user.cookie);assert.ok(user.body.csrfToken);
  const publicState=await fetch(base+'/api/learning/state');assert.equal(publicState.status,401);
  const blockedWrite=await fetch(base+'/api/learning/state',{method:'PUT',headers:{cookie:user.cookie,'Content-Type':'application/json'},body:JSON.stringify({subjects:[]})});
  assert.equal(blockedWrite.status,403);
  const state={schema:1,preferences:{lang:'ar',theme:'light'},subjects:[{id:'sub-1',name:'Anatomy',description:''}],lectures:[],notes:[{id:'note-1',subjectId:'sub-1',title:'Week 1',body:'Verified content'}],cards:[],questions:[],tasks:[],sessions:[],quizAttempts:[],reviewHistory:[],folders:[],aiConversations:[]};
  const saved=await fetch(base+'/api/learning/state',{method:'PUT',headers:{cookie:user.cookie,'X-CSRF-Token':user.body.csrfToken,'Content-Type':'application/json'},body:JSON.stringify(state)});
  assert.equal(saved.status,200);
  const fetched=await fetch(base+'/api/learning/state',{headers:{cookie:user.cookie}});assert.equal(fetched.status,200);
  const savedState=await fetched.json();assert.equal(savedState.state.subjects[0].name,'Anatomy');assert.equal(savedState.revision,1);
  assert.equal(server.midadDb.prepare('SELECT COUNT(*) n FROM notes WHERE owner_id=?').get(user.body.user.id).n,1);
  const admin=await fetch(base+'/api/admin/overview',{headers:{cookie:user.cookie}});assert.equal(admin.status,403);
  const second=await register(base);
  const otherState=await fetch(base+'/api/learning/state',{headers:{cookie:second.cookie}});assert.equal((await otherState.json()).state.subjects.length,0);
  const previousBootstrapEmail=process.env.MIDAD_INITIAL_ADMIN_EMAIL;process.env.MIDAD_INITIAL_ADMIN_EMAIL='unverified-admin@example.invalid';
  let unverifiedAdmin;try{unverifiedAdmin=await register(base,'unverified-admin@example.invalid');}finally{if(previousBootstrapEmail===undefined)delete process.env.MIDAD_INITIAL_ADMIN_EMAIL;else process.env.MIDAD_INITIAL_ADMIN_EMAIL=previousBootstrapEmail;}
  assert.equal(unverifiedAdmin.body.user.role,'student');assert.equal(unverifiedAdmin.body.emailVerified,false);
});

test('session refresh keeps CSRF stable across tabs and rejects mismatched origin scheme',async t=>{
  const {base}=await startTestServer(t);
  const user=await register(base);
  const first=await fetch(base+'/api/auth/session',{headers:{cookie:user.cookie}});
  const firstData=await first.json();
  const second=await fetch(base+'/api/auth/session',{headers:{cookie:user.cookie}});
  const secondData=await second.json();
  assert.equal(firstData.csrfToken,user.body.csrfToken);
  assert.equal(secondData.csrfToken,firstData.csrfToken);

  const httpsOrigin=`https://${new URL(base).host}`;
  const wrongScheme=await fetch(base+'/api/learning/state',{method:'PUT',headers:{cookie:user.cookie,Origin:httpsOrigin,'X-CSRF-Token':firstData.csrfToken,'Content-Type':'application/json'},body:JSON.stringify({subjects:[]})});
  assert.equal(wrongScheme.status,403);
  const accepted=await fetch(base+'/api/learning/state',{method:'PUT',headers:{cookie:user.cookie,Origin:base,'X-CSRF-Token':firstData.csrfToken,'Content-Type':'application/json'},body:JSON.stringify({subjects:[]})});
  assert.equal(accepted.status,200);

  const oldProxy=process.env.MIDAD_TRUST_PROXY;
  process.env.MIDAD_TRUST_PROXY='false';
  try{
    const spoofed=await fetch(base+'/api/auth/register',{method:'POST',headers:{Origin:'http://attacker.invalid','X-Forwarded-Host':'attacker.invalid','Content-Type':'application/json'},body:JSON.stringify({email:randomUUID()+'@example.invalid',username:'spoof-'+randomUUID().slice(0,8),password:'test-only-password-This-is-not-real-22',displayName:'MIDAD Test'})});
    assert.equal(spoofed.status,403);
  }finally{if(oldProxy===undefined)delete process.env.MIDAD_TRUST_PROXY;else process.env.MIDAD_TRUST_PROXY=oldProxy;}
});

test('concurrent local uploads reserve account quota atomically',async t=>{
  const {base,server}=await startTestServer(t);
  const user=await register(base);
  const content='Concurrent upload quota test with valid searchable text.';
  const size=Buffer.byteLength(content),now=new Date().toISOString();
  server.midadDb.prepare(`INSERT INTO files(owner_id,id,filename,media_type,size_bytes,status,storage_key,preview_kind,created_at,updated_at)
    VALUES(?,?,?,'text/plain',?,'failed',?,'download',?,?)`).run(user.body.user.id,'quota-baseline','baseline.txt',300*1024*1024-size,'quota-baseline.bin',now,now);
  const upload=filename=>fetch(base+'/api/files/upload?name='+encodeURIComponent(filename),{method:'POST',headers:{cookie:user.cookie,'X-CSRF-Token':user.body.csrfToken,'Content-Type':'text/plain','X-Midad-Mime':'text/plain'},body:content});
  const responses=await Promise.all([upload('first.txt'),upload('second.txt')]);
  assert.deepEqual(responses.map(response=>response.status).sort(),[201,413]);
  const total=server.midadDb.prepare('SELECT SUM(size_bytes) total FROM files WHERE owner_id=?').get(user.body.user.id).total;
  assert.equal(total,300*1024*1024);
});

test('failed file reservation does not leave an orphan on disk',async t=>{
  const {base,server,dataDir}=await startTestServer(t);
  const user=await register(base);
  server.midadDb.exec("CREATE TRIGGER reject_file_reservation BEFORE INSERT ON files BEGIN SELECT RAISE(ABORT,'test reservation failure'); END");
  const response=await fetch(base+'/api/files/upload?name=lesson.txt',{method:'POST',headers:{cookie:user.cookie,'X-CSRF-Token':user.body.csrfToken,'Content-Type':'text/plain','X-Midad-Mime':'text/plain'},body:'This is a valid text file for upload.'});
  assert.equal(response.status,500);
  const userDir=path.join(dataDir,'private',user.body.user.id);
  assert.deepEqual(fs.readdirSync(userDir),[]);
  assert.equal(server.midadDb.prepare('SELECT COUNT(*) n FROM files WHERE owner_id=?').get(user.body.user.id).n,0);
});

test('file upload is processed, private and protected against IDOR', async t => {
  const {base}=await startTestServer(t);
  const user=await register(base),other=await register(base);
  const content='Insulin regulates glucose uptake through pathways involving receptor signaling and cellular responses. '.repeat(8);
  const upload=await fetch(base+'/api/files/upload?name='+encodeURIComponent('physiology.txt'),{
    method:'POST',headers:{cookie:user.cookie,'X-CSRF-Token':user.body.csrfToken,'Content-Type':'text/plain','X-Midad-Mime':'text/plain'},body:content,
  });
  assert.equal(upload.status,201);const result=await upload.json();assert.equal(result.file.status,'ready');assert.ok(result.file.extractedChars>20);
  const own=await fetch(base+`/api/files/${result.file.id}/content`,{headers:{cookie:user.cookie}});assert.equal(own.status,200);assert.equal(await own.text(),content);
  const intruder=await fetch(base+`/api/files/${result.file.id}/content`,{headers:{cookie:other.cookie}});assert.equal(intruder.status,404);
  const fileChunks=await fetch(base+'/api/files',{headers:{cookie:user.cookie}});assert.equal((await fileChunks.json()).files.length,1);
  const search=await fetch(base+'/api/search?q=insulin',{headers:{cookie:user.cookie}});assert.equal(search.status,200);const hits=(await search.json()).results;assert.ok(hits.some(hit=>hit.id===result.file.id&&hit.excerpt.toLowerCase().includes('insulin')));
  const update=await fetch(base+`/api/files/${result.file.id}`,{method:'PATCH',headers:{cookie:user.cookie,'X-CSRF-Token':user.body.csrfToken,'Content-Type':'application/json'},body:JSON.stringify({favorite:true,name:'physiology-renamed.txt'})});assert.equal(update.status,200);assert.equal((await update.json()).file.favorite,true);
  const updatedRows=await fetch(base+'/api/files',{headers:{cookie:user.cookie}});const updatedFile=(await updatedRows.json()).files[0];assert.equal(updatedFile.name,'physiology-renamed.txt');assert.equal(updatedFile.favorite,true);
  const deniedUpdate=await fetch(base+`/api/files/${result.file.id}`,{method:'PATCH',headers:{cookie:other.cookie,'X-CSRF-Token':other.body.csrfToken,'Content-Type':'application/json'},body:JSON.stringify({favorite:false})});assert.equal(deniedUpdate.status,404);
  const deleted=await fetch(base+`/api/files/${result.file.id}`,{method:'DELETE',headers:{cookie:other.cookie,'X-CSRF-Token':other.body.csrfToken}});assert.equal(deleted.status,404);
});
