import { randomUUID } from 'node:crypto';

const DEFAULT_LEARNING_STATE = {
  schema: 1,
  preferences: { lang: 'ar', theme: 'light' },
  subjects: [], lectures: [], notes: [], cards: [], questions: [], tasks: [],
  sessions: [], quizAttempts: [], reviewHistory: [], folders: [],
  activeQuiz: null, timer: null, aiConversations: [],
};

function mapLearningRow(row) {
  if (!row) return null;
  const raw = row.state_json;
  return {
    state: typeof raw === 'string' ? JSON.parse(raw) : raw,
    revision: Number(row.revision),
    updatedAt: new Date(row.updated_at).toISOString(),
  };
}

export function createPostgresRepository(pool) {
  return {
    async health() {
      await pool.query('SELECT 1');
      return true;
    },

    async registerUser({ user, profile, session }) {
      const client = await pool.connect();
      try {
        await client.query('BEGIN');
        await client.query(
          `INSERT INTO users(id,email,password_hash,role,email_verified,disabled,created_at)
           VALUES($1,$2,$3,'student',FALSE,FALSE,$4)`,
          [user.id,user.email,user.passwordHash,user.createdAt],
        );
        await client.query(
          `INSERT INTO profiles(user_id,username,display_name,locale,created_at,updated_at)
           VALUES($1,$2,$3,'ar',$4,$4)`,
          [user.id,profile.username,profile.displayName,user.createdAt],
        );
        await client.query(
          `INSERT INTO sessions(token_hash,user_id,csrf_hash,expires_at,created_at)
           VALUES($1,$2,$3,$4,$5)`,
          [session.tokenHash,user.id,session.csrfHash,session.expiresAt,session.createdAt],
        );
        await client.query('COMMIT');
        return { user_id:user.id,email:user.email,username:profile.username,display_name:profile.displayName,role:'student',locale:'ar' };
      } catch (error) {
        try { await client.query('ROLLBACK'); } catch {}
        throw error;
      } finally {
        client.release();
      }
    },

    async findUserByIdentity(email, username) {
      const { rows } = await pool.query(
        `SELECT u.id,u.email,u.password_hash,u.role,u.disabled,
                p.username,p.display_name,p.locale
         FROM users u LEFT JOIN profiles p ON p.user_id=u.id
         WHERE lower(u.email)=lower($1) OR lower(p.username)=lower($2)
         LIMIT 1`,
        [email || '',username || ''],
      );
      return rows[0] || null;
    },

    async setLastLogin(userId, at) {
      await pool.query('UPDATE users SET last_login_at=$1 WHERE id=$2',[at,userId]);
    },

    async createSession({ tokenHash,userId,csrfHash,expiresAt,createdAt }) {
      await pool.query(
        'INSERT INTO sessions(token_hash,user_id,csrf_hash,expires_at,created_at) VALUES($1,$2,$3,$4,$5)',
        [tokenHash,userId,csrfHash,expiresAt,createdAt],
      );
    },

    async findSession(tokenHash, now) {
      const { rows } = await pool.query(
        `SELECT s.token_hash,s.user_id,s.csrf_hash,s.expires_at,
                u.email,u.role,u.disabled,p.username,p.display_name,p.locale
         FROM sessions s JOIN users u ON u.id=s.user_id
         LEFT JOIN profiles p ON p.user_id=u.id
         WHERE s.token_hash=$1 AND s.expires_at>$2 AND u.disabled=FALSE`,
        [tokenHash,now],
      );
      return rows[0] || null;
    },

    async updateSessionCsrf(tokenHash, csrfHash) {
      const result = await pool.query('UPDATE sessions SET csrf_hash=$1 WHERE token_hash=$2',[csrfHash,tokenHash]);
      return result.rowCount > 0;
    },

    async deleteSession(tokenHash) {
      await pool.query('DELETE FROM sessions WHERE token_hash=$1',[tokenHash]);
    },

    async updateProfile(userId, displayName, locale, now) {
      const result = await pool.query(
        'UPDATE profiles SET display_name=$1,locale=$2,updated_at=$3 WHERE user_id=$4',
        [displayName,locale,now,userId],
      );
      return result.rowCount > 0;
    },

    async readLearningState(userId) {
      const { rows } = await pool.query('SELECT state_json,revision,updated_at FROM learning_state WHERE user_id=$1',[userId]);
      return rows[0] ? mapLearningRow(rows[0]) : null;
    },

    async writeLearningState(userId, state, now) {
      const { rows } = await pool.query(
        `INSERT INTO learning_state(user_id,state_json,revision,updated_at)
         VALUES($1,$2::jsonb,1,$3)
         ON CONFLICT(user_id) DO UPDATE
           SET state_json=EXCLUDED.state_json,
               revision=learning_state.revision+1,
               updated_at=EXCLUDED.updated_at
         RETURNING state_json,revision,updated_at`,
        [userId,JSON.stringify(state),now],
      );
      return mapLearningRow(rows[0]);
    },

    async subjectExists(userId, subjectId) {
      const { rows } = await pool.query(
        `SELECT 1 FROM learning_state
         WHERE user_id=$1 AND EXISTS (
           SELECT 1 FROM jsonb_array_elements(COALESCE(state_json->'subjects','[]'::jsonb)) item
           WHERE item->>'id'=$2
         )`,
        [userId,subjectId],
      );
      return rows.length > 0;
    },

    async fileQuotaBytes(userId) {
      const { rows } = await pool.query('SELECT COALESCE(SUM(size_bytes),0)::bigint AS total FROM files WHERE owner_id=$1',[userId]);
      return Number(rows[0]?.total || 0);
    },

    async insertFileWithinQuota(file, quotaBytes) {
      const client = await pool.connect();
      try {
        await client.query('BEGIN');
        const profile = await client.query('SELECT user_id FROM profiles WHERE user_id=$1 FOR UPDATE',[file.ownerId]);
        if (!profile.rowCount) throw new Error('profile_missing');
        const usage = await client.query('SELECT COALESCE(SUM(size_bytes),0)::bigint AS total FROM files WHERE owner_id=$1',[file.ownerId]);
        if (Number(usage.rows[0].total) + file.sizeBytes > quotaBytes) throw new Error('storage_quota');
        const { rows } = await client.query(
          `INSERT INTO files(owner_id,id,filename,media_type,size_bytes,status,storage_key,preview_kind,folder_id,subject_id,created_at,updated_at)
           VALUES($1,$2,$3,$4,$5,'processing',$6,$7,$8,$9,$10,$10) RETURNING *`,
          [file.ownerId,file.id,file.filename,file.mediaType,file.sizeBytes,file.storageKey,file.previewKind,file.folderId,file.subjectId,file.createdAt],
        );
        await client.query('COMMIT');
        return rows[0];
      } catch (error) {
        try { await client.query('ROLLBACK'); } catch {}
        throw error;
      } finally {
        client.release();
      }
    },

    async setFileProcessing(ownerId, fileId, { status, extractedChars=0, processingError=null, updatedAt }) {
      const { rows } = await pool.query(
        `UPDATE files SET status=$1,extracted_chars=$2,processing_error=$3,updated_at=$4
         WHERE owner_id=$5 AND id=$6 RETURNING *`,
        [status,extractedChars,processingError,updatedAt,ownerId,fileId],
      );
      return rows[0] || null;
    },

    async insertTextChunks(ownerId, fileId, chunks) {
      if (!chunks.length) return;
      await pool.query(
        `INSERT INTO file_chunks(owner_id,file_id,chunk_no,page_no,section,content)
         SELECT * FROM unnest($1::text[],$2::text[],$3::integer[],$4::integer[],$5::text[],$6::text[])`,
        [
          chunks.map(()=>ownerId),chunks.map(()=>fileId),chunks.map((_,i)=>i+1),
          chunks.map(c=>c.page),chunks.map(c=>c.section || ''),chunks.map(c=>c.content),
        ],
      );
    },

    async listFiles(userId) {
      const { rows } = await pool.query('SELECT * FROM files WHERE owner_id=$1 ORDER BY created_at DESC',[userId]);
      return rows;
    },

    async getFile(userId, fileId) {
      const { rows } = await pool.query('SELECT * FROM files WHERE owner_id=$1 AND id=$2',[userId,fileId]);
      return rows[0] || null;
    },

    async updateFile(userId, fileId, patch, now) {
      const { rows } = await pool.query(
        `UPDATE files SET filename=$1,favorite=$2,folder_id=$3,subject_id=$4,updated_at=$5
         WHERE owner_id=$6 AND id=$7 RETURNING *`,
        [patch.filename,patch.favorite,patch.folderId,patch.subjectId,now,userId,fileId],
      );
      return rows[0] || null;
    },

    async deleteFile(userId, fileId) {
      const { rows } = await pool.query('DELETE FROM files WHERE owner_id=$1 AND id=$2 RETURNING storage_key',[userId,fileId]);
      return rows[0] || null;
    },

    async searchFiles(userId, terms) {
      const params = [userId];
      const conditions = terms.map(term => {
        params.push(term);
        const n = params.length;
        return `(position($${n} in lower(c.content))>0 OR position($${n} in lower(f.filename))>0)`;
      });
      const { rows } = await pool.query(
        `SELECT f.id,f.filename,f.status,c.page_no,c.section,substr(c.content,1,220) AS excerpt,
                f.created_at,c.chunk_no
         FROM file_chunks c JOIN files f ON f.owner_id=c.owner_id AND f.id=c.file_id
         WHERE c.owner_id=$1 AND f.status='ready' AND (${conditions.join(' OR ')})
         ORDER BY f.created_at DESC,c.chunk_no LIMIT 12`,
        params,
      );
      return rows;
    },

    async addSearchHistory(userId, id, queryHash, createdAt) {
      await pool.query(
        'INSERT INTO search_history(owner_id,id,query_hash,created_at) VALUES($1,$2,$3,$4)',
        [userId,id,queryHash,createdAt],
      );
    },

    async hitRateLimit(scope, subject, nowMs, windowMs) {
      const bucket = Math.floor(nowMs / windowMs);
      const { rows } = await pool.query(
        `INSERT INTO rate_limits(scope,subject,bucket,hits) VALUES($1,$2,$3,1)
         ON CONFLICT(scope,subject,bucket) DO UPDATE SET hits=rate_limits.hits+1
         RETURNING hits`,
        [scope,subject,bucket],
      );
      return Number(rows[0].hits);
    },

    async audit(userId, action, type=null, id=null, outcome='success', createdAt=new Date().toISOString()) {
      await pool.query(
        'INSERT INTO audit_logs(id,actor_id,action,resource_type,resource_id,outcome,created_at) VALUES($1,$2,$3,$4,$5,$6,$7)',
        [randomUUID(),userId || null,action,type,id,outcome,createdAt],
      );
    },

    async adminOverview() {
      const { rows } = await pool.query(
        `SELECT (SELECT COUNT(*) FROM users) AS users,
                (SELECT COUNT(*) FROM files) AS files,
                0::bigint AS ai_requests`,
      );
      return { users:Number(rows[0].users),files:Number(rows[0].files),aiRequests:Number(rows[0].ai_requests) };
    },
  };
}

export { DEFAULT_LEARNING_STATE };
