import path from 'node:path';
import { File } from 'node:buffer';
import { createHash, randomBytes, randomUUID, scrypt as scryptCallback, timingSafeEqual } from 'node:crypto';
import { promisify } from 'node:util';
import { sanitizeLocalFileName, validateLocalFile } from '../file-policy.mjs';
import { DEFAULT_LEARNING_STATE } from './repository.mjs';

const scrypt = promisify(scryptCallback);
const SESSION_TTL_MS = 14 * 24 * 60 * 60 * 1000;
export const NETLIFY_MAX_UPLOAD_BYTES = 4 * 1024 * 1024;
const USER_QUOTA_BYTES = 300 * 1024 * 1024;
const MAX_STATE_BYTES = 5 * 1024 * 1024;
const MIME_BY_EXT = {
  pdf:'application/pdf', txt:'text/plain', md:'text/markdown',
  doc:'application/msword', docx:'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  ppt:'application/vnd.ms-powerpoint', pptx:'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  png:'image/png', jpg:'image/jpeg', jpeg:'image/jpeg', webp:'image/webp',
  mp3:'audio/mpeg', wav:'audio/wav', mp4:'video/mp4', mov:'video/quicktime',
};

function hash(value) { return createHash('sha256').update(value).digest('hex'); }
function secureEqual(a,b) {
  const left=Buffer.from(String(a||'')),right=Buffer.from(String(b||''));
  return left.length===right.length && timingSafeEqual(left,right);
}
function parseCookies(header) {
  const out={};
  for (const part of String(header||'').split(';')) {
    const i=part.indexOf('=');
    if (i<0) continue;
    const name=part.slice(0,i).trim(), value=part.slice(i+1).trim();
    if (name && value) out[name]=value;
  }
  return out;
}
function safePath(url) {
  try {
    let pathname=url.pathname;
    for (let i=0;i<2;i++) pathname=decodeURIComponent(pathname);
    if (pathname.includes('\\') || pathname.includes('\0') || pathname.split('/').some(x=>x==='.'||x==='..')) return null;
    return pathname;
  } catch { return null; }
}
function checkOrigin(request,url) {
  const origin=request.headers.get('origin');
  if (!origin) return true;
  try {
    const parsed=new URL(origin);
    return ['http:','https:'].includes(parsed.protocol)&&parsed.origin.toLowerCase()===url.origin.toLowerCase();
  }
  catch { return false; }
}
function normalizeEmail(value) {
  const email=String(value||'').trim().normalize('NFKC').toLowerCase();
  if (email.length>254 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return null;
  return email;
}
function normalizeUsername(value) {
  const username=String(value||'').trim().normalize('NFKC');
  if (username.length<3 || username.length>32 || !/^[A-Za-z0-9][A-Za-z0-9_.-]{2,31}$/.test(username)) return null;
  return username;
}
function safeId(value) { return typeof value==='string' && /^[a-zA-Z0-9-]{1,80}$/.test(value); }
function publicUser(row) {
  return {
    id:row.user_id,email:row.email,username:row.username||'',
    displayName:row.display_name||'',role:row.role,locale:row.locale||'ar',
  };
}
function normalizeState(input) {
  if (!input || typeof input!=='object' || Array.isArray(input)) throw new Error('invalid_state');
  const state={...structuredClone(DEFAULT_LEARNING_STATE),...input};
  state.preferences={lang:input.preferences?.lang==='en'?'en':'ar',theme:input.preferences?.theme==='dark'?'dark':'light'};
  const keys=Object.keys(DEFAULT_LEARNING_STATE).filter(key=>Array.isArray(DEFAULT_LEARNING_STATE[key]));
  for (const key of keys) {
    const values=Array.isArray(input[key])?input[key]:[];
    if (values.length>5000) throw new Error('too_many_records');
    state[key]=values.filter(item=>item&&typeof item==='object'&&!Array.isArray(item)&&safeId(item.id)).map(item=>JSON.parse(JSON.stringify(item)));
  }
  const subjects=new Set(state.subjects.map(item=>item.id));
  for (const key of ['lectures','notes','cards','questions','tasks']) state[key]=state[key].filter(item=>!item.subjectId||subjects.has(item.subjectId));
  state.schema=1;
  return state;
}
function safeFileRow(row) {
  return {
    id:row.id,name:row.filename,type:row.media_type,previewKind:row.preview_kind,
    size:Number(row.size_bytes),addedAt:new Date(row.created_at).toISOString(),
    favorite:Boolean(row.favorite),folderId:row.folder_id||null,subjectId:row.subject_id||'',
    status:row.status,processingError:row.processing_error||null,extractedChars:Number(row.extracted_chars||0),
  };
}
function mimeOkay(ext,mime) {
  if (!mime || mime==='application/octet-stream') return true;
  if (ext==='md') return ['text/markdown','text/plain'].includes(mime);
  if (ext==='wav') return ['audio/wav','audio/x-wav','audio/wave'].includes(mime);
  return mime===MIME_BY_EXT[ext];
}
function signatureOkay(ext,bytes) {
  const starts=(...values)=>values.every((value,index)=>bytes[index]===value);
  if (ext==='pdf') return bytes.length>=5&&starts(0x25,0x50,0x44,0x46,0x2d);
  if (ext==='png') return bytes.length>=8&&starts(0x89,0x50,0x4e,0x47,0x0d,0x0a,0x1a,0x0a);
  if (ext==='jpg'||ext==='jpeg') return bytes.length>=3&&starts(0xff,0xd8,0xff);
  if (ext==='webp') return bytes.length>=12&&starts(0x52,0x49,0x46,0x46)&&bytes[8]===0x57&&bytes[9]===0x45&&bytes[10]===0x42&&bytes[11]===0x50;
  if (ext==='docx'||ext==='pptx') return bytes.length>=4&&starts(0x50,0x4b);
  if (ext==='doc'||ext==='ppt') return bytes.length>=8&&starts(0xd0,0xcf,0x11,0xe0,0xa1,0xb1,0x1a,0xe1);
  if (ext==='wav') return bytes.length>12&&bytes.toString('ascii',0,4)==='RIFF'&&bytes.toString('ascii',8,12)==='WAVE';
  if (ext==='mp3') return bytes.length>3&&(bytes.toString('ascii',0,3)==='ID3'||(bytes[0]===0xff&&(bytes[1]&0xe0)===0xe0));
  if (ext==='mp4'||ext==='mov') return bytes.length>=12&&bytes.toString('ascii',4,8)==='ftyp';
  return true;
}
function makeChunks(text,{chunkSize=1200,overlap=160,maxChunks=5000}={}) {
  const chunks=[];
  let start=0;
  while(start<text.length&&chunks.length<maxChunks){
    let end=Math.min(text.length,start+chunkSize);
    if(end<text.length){const boundary=text.lastIndexOf('\n',end);if(boundary>start+chunkSize*0.65)end=boundary;}
    const content=text.slice(start,end).trim();
    if(content)chunks.push({page:null,section:'',content});
    if(end>=text.length)break;
    start=Math.max(start+1,end-overlap);
  }
  return chunks;
}
function attachmentName(name) {
  return encodeURIComponent(name).replace(/[!'()*]/g,char=>`%${char.charCodeAt(0).toString(16).toUpperCase()}`);
}
function blobKey(userId,fileId) { return `users/${userId}/${fileId}`; }

export function createMidadApi({ repository, fileStore, clock=()=>new Date(), getIp=(_request,context)=>context?.ip||'unknown' }) {
  if (!repository || !fileStore) throw new TypeError('repository and fileStore are required');

  return async function handleMidadRequest(request,context={}) {
    const url=new URL(request.url);
    const pathName=safePath(url);
    const security={
      'Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; media-src 'self' blob:; frame-src blob:; worker-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'",
      'X-Content-Type-Options':'nosniff','X-Frame-Options':'DENY',
      'Referrer-Policy':'strict-origin-when-cross-origin',
      'Permissions-Policy':'camera=(), microphone=(), geolocation=(), payment=()',
      'Cross-Origin-Opener-Policy':'same-origin','Cross-Origin-Resource-Policy':'same-origin',
      'Cache-Control':'no-store',
    };
    if(url.protocol==='https:')security['Strict-Transport-Security']='max-age=31536000; includeSubDomains';
    const json=(status,body,extra={})=>Response.json(body,{status,headers:{...security,...extra}});
    const error=(status,code,message='تعذّر تنفيذ الطلب.')=>json(status,{error:code,message});
    const now=()=>clock();
    const originOkay=()=>checkOrigin(request,url);
    const ip=String(getIp(request,context)||'unknown').slice(0,120);
    const limited=async(scope,subject,maximum,windowMs)=>await repository.hitRateLimit(scope,String(subject||'unknown').slice(0,200),now().getTime(),windowMs)<=maximum;
    const audit=async(...args)=>{try{await repository.audit(...args,now().toISOString());}catch{}};
    const cookie=(token)=>`midad.sid=${token}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${Math.floor(SESSION_TTL_MS/1000)}${url.protocol==='https:'?'; Secure':''}`;
    const clearCookie=()=>`midad.sid=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0${url.protocol==='https:'?'; Secure':''}`;
    const readJson=async(limit=128*1024)=>{
      const length=Number(request.headers.get('content-length')||0);
      if(length>limit)throw Object.assign(new Error('body_too_large'),{status:413});
      const raw=Buffer.from(await request.arrayBuffer());
      if(raw.length>limit)throw Object.assign(new Error('body_too_large'),{status:413});
      try{const value=JSON.parse(raw.toString('utf8'));if(!value||typeof value!=='object'||Array.isArray(value))throw new Error();return value;}
      catch{throw Object.assign(new Error('invalid_json'),{status:400});}
    };
    const getAuth=async()=>{
      const token=parseCookies(request.headers.get('cookie'))['midad.sid'];
      if(!token||!/^[\w-]{40,60}$/.test(token))return null;
      const row=await repository.findSession(hash(token),now().toISOString());
      return row?{...row,token}:null;
    };
    const requireCsrf=(auth)=>Boolean(auth&&originOkay()&&secureEqual(hash(String(request.headers.get('x-csrf-token')||'')),auth.csrf_hash));
    const sessionMaterial=(userId)=>{
      const token=randomBytes(32).toString('base64url');
      const csrf=createHash('sha256').update(`midad-csrf:${token}`).digest('base64url');
      const created=now();
      return {token,csrf,record:{tokenHash:hash(token),userId,csrfHash:hash(csrf),expiresAt:new Date(created.getTime()+SESSION_TTL_MS).toISOString(),createdAt:created.toISOString()}};
    };
    const method=request.method.toUpperCase();
    if(method==='OPTIONS')return new Response(null,{status:405,headers:{...security,'Allow':'GET, HEAD, POST, PUT, PATCH, DELETE'}});
    if(!pathName)return error(400,'invalid_path','مسار الطلب غير صالح.');
    if(pathName==='/api/health'&&method==='GET'){
      try{await repository.health();return json(200,{ok:true,backend:'netlify-postgres-blobs',authentication:true,aiConfigured:false,uploadMaxBytes:NETLIFY_MAX_UPLOAD_BYTES,scientificSources:[]});}
      catch{return json(503,{ok:false,backend:'netlify-postgres-blobs',authentication:false,aiConfigured:false,uploadMaxBytes:NETLIFY_MAX_UPLOAD_BYTES});}
    }
    if(!pathName.startsWith('/api/'))return error(404,'not_found','المسار غير موجود.');

    try{
      let auth=await getAuth();
      if(pathName==='/api/auth/register'&&method==='POST'){
        if(!originOkay())return error(403,'origin_rejected','الطلب ليس من نفس الموقع.');
        if(!await limited('register:ip',ip,5,15*60*1000))return error(429,'auth_rate_limited','محاولات كثيرة؛ حاول لاحقًا.');
        const body=await readJson(32*1024);
        const email=normalizeEmail(body.email),username=normalizeUsername(body.username),password=String(body.password||'');
        const displayName=String(body.displayName||'').normalize('NFKC').trim().replace(/[\u0000-\u001f\u007f]/g,'').slice(0,80);
        if(!email)return error(400,'invalid_email','أدخل بريدًا إلكترونيًا صالحًا.');
        if(!username)return error(400,'invalid_username','اسم المستخدم يجب أن يكون من 3 إلى 32 حرفًا أو رقمًا أو نقطة أو شرطة سفلية أو واصلة.');
        if(password.length<12||password.length>128)return error(400,'password_policy','كلمة المرور يجب أن تكون بين 12 و128 حرفًا.');
        if(!displayName)return error(400,'display_name_required','أدخل الاسم الظاهر.');
        const salt=randomBytes(16);
        const derived=await scrypt(password,salt,64,{N:16384,r:8,p:1,maxmem:64*1024*1024});
        const passwordHash=`scrypt$16384$8$1$${salt.toString('base64url')}$${Buffer.from(derived).toString('base64url')}`;
        const id=randomUUID(),createdAt=now().toISOString(),session=sessionMaterial(id);
        let row;
        try{
          row=await repository.registerUser({
            user:{id,email,passwordHash,createdAt},profile:{username,displayName},session:session.record,
          });
        }catch(e){
          if(e.code==='23505'||String(e.message).includes('duplicate key')){
            const constraint=String(e.constraint||e.message||'');
            if(constraint.includes('username'))return error(409,'username_taken','اسم المستخدم مستخدم بالفعل. اختر اسمًا آخر.');
            return error(409,'account_exists','يوجد حساب بهذا البريد بالفعل.');
          }
          throw e;
        }
        await audit(id,'auth.register','user',id,'success');
        return json(201,{user:publicUser(row),csrfToken:session.csrf,emailVerified:false},{'Set-Cookie':cookie(session.token)});
      }
      if(pathName==='/api/auth/login'&&method==='POST'){
        if(!originOkay())return error(403,'origin_rejected','الطلب ليس من نفس الموقع.');
        if(!await limited('login:ip',ip,8,15*60*1000))return error(429,'auth_rate_limited','محاولات كثيرة؛ حاول لاحقًا.');
        const body=await readJson(32*1024);
        const identifier=String(body.identifier||body.email||'').trim();
        const email=normalizeEmail(identifier),username=normalizeUsername(identifier),password=String(body.password||'');
        const row=(email||username)?await repository.findUserByIdentity(email||'',username||''):null;
        let valid=false;
        if(row&&!row.disabled){
          try{
            const [scheme,n,r,p,saltText,hashText]=String(row.password_hash||'').split('$');
            if(scheme==='scrypt'&&Number(n)===16384&&Number(r)===8&&Number(p)===1){
              const salt=Buffer.from(saltText,'base64url'),expected=Buffer.from(hashText,'base64url');
              const actual=Buffer.from(await scrypt(password,salt,expected.length,{N:16384,r:8,p:1,maxmem:64*1024*1024}));
              valid=secureEqual(actual,expected);
            }
          }catch{valid=false;}
        }
        if(!valid){await audit(null,'auth.login','user',null,'rejected');return error(401,'invalid_credentials','البريد أو اسم المستخدم أو كلمة المرور غير صحيحة.');}
        const session=sessionMaterial(row.id);
        await repository.setLastLogin(row.id,now().toISOString());
        await repository.createSession({...session.record,userId:row.id});
        await audit(row.id,'auth.login','user',row.id,'success');
        const user={user_id:row.id,email:row.email,username:row.username,display_name:row.display_name,role:row.role,locale:row.locale};
        return json(200,{user:publicUser(user),csrfToken:session.csrf,emailVerified:false},{'Set-Cookie':cookie(session.token)});
      }
      if(pathName==='/api/auth/session'&&method==='GET'){
        if(!auth)return json(200,{authenticated:false});
        const csrfToken=createHash('sha256').update(`midad-csrf:${auth.token}`).digest('base64url');
        if(auth.csrf_hash!==hash(csrfToken)&&!await repository.updateSessionCsrf(auth.token_hash,hash(csrfToken)))return json(200,{authenticated:false},{'Set-Cookie':clearCookie()});
        return json(200,{authenticated:true,user:publicUser(auth),csrfToken,emailVerified:false});
      }
      if(pathName==='/api/auth/logout'&&method==='POST'){
        if(auth&&!requireCsrf(auth))return error(403,'csrf_rejected','انتهت صلاحية الجلسة؛ أعد تحميل الصفحة.');
        if(auth){await repository.deleteSession(auth.token_hash);await audit(auth.user_id,'auth.logout','user',auth.user_id,'success');}
        return json(200,{ok:true},{'Set-Cookie':clearCookie()});
      }
      if(!auth)return error(401,'authentication_required','سجّل الدخول للمتابعة.');
      if(['POST','PUT','PATCH','DELETE'].includes(method)&&!requireCsrf(auth))return error(403,'csrf_rejected','انتهت صلاحية الجلسة؛ أعد تحميل الصفحة.');

      if(pathName==='/api/profile'&&method==='PATCH'){
        const body=await readJson(16*1024);
        const displayName=String(body.displayName||'').trim().slice(0,80),locale=body.locale==='en'?'en':'ar';
        if(!displayName)return error(400,'display_name_required','الاسم الظاهر مطلوب.');
        if(!await repository.updateProfile(auth.user_id,displayName,locale,now().toISOString()))return error(404,'profile_not_found','الملف الشخصي غير موجود.');
        return json(200,{ok:true});
      }
      if(pathName==='/api/learning/state'&&method==='GET'){
        return json(200,await repository.readLearningState(auth.user_id)||{state:DEFAULT_LEARNING_STATE,revision:0,updatedAt:null});
      }
      if(pathName==='/api/learning/state'&&method==='PUT'){
        const body=await readJson(MAX_STATE_BYTES);
        try{
          const state=normalizeState(body);
          if(Buffer.byteLength(JSON.stringify(state))>MAX_STATE_BYTES)throw new Error('state_too_large');
          return json(200,await repository.writeLearningState(auth.user_id,state,now().toISOString()));
        }catch(e){
          const code=['state_too_large','too_many_records'].includes(e.message)?e.message:e.message==='invalid_state'?'invalid_state':'invalid_state';
          return error(code==='state_too_large'||code==='too_many_records'?413:400,code,'تعذر حفظ بيانات التعلّم.');
        }
      }
      if(pathName==='/api/files'&&method==='GET'){
        return json(200,{files:(await repository.listFiles(auth.user_id)).map(safeFileRow)});
      }
      if(pathName==='/api/search'&&method==='GET'){
        if(!await limited('search:user',auth.user_id,90,60*1000))return error(429,'search_rate_limited','أجرِ عمليات بحث أقل قليلًا.');
        const query=String(url.searchParams.get('q')||'').trim().slice(0,160);
        if(query.length<2)return json(200,{results:[]});
        const terms=[...new Set(query.toLocaleLowerCase().split(/[^\p{L}\p{N}]+/u).filter(term=>term.length>1))].slice(0,8);
        if(!terms.length)return json(200,{results:[]});
        const results=await repository.searchFiles(auth.user_id,terms);
        await repository.addSearchHistory(auth.user_id,randomUUID(),hash(query.toLocaleLowerCase()),now().toISOString());
        return json(200,{results:results.map(row=>({id:row.id,name:row.filename,page:row.page_no,section:row.section,excerpt:row.excerpt}))});
      }
      if(pathName==='/api/files/upload'&&method==='POST'){
        if(!await limited('upload:user',auth.user_id,8,60*60*1000)||!await limited('upload:ip',ip,12,60*60*1000))return error(429,'upload_rate_limited','وصلت إلى حد الرفع المؤقت؛ حاول لاحقًا.');
        const advertised=Number(request.headers.get('content-length')||0);
        if(advertised>NETLIFY_MAX_UPLOAD_BYTES)return error(413,'file_too_large','الحد الأقصى للرفع على استضافة Netlify الحالية 4 ميغابايت.');
        const name=sanitizeLocalFileName(url.searchParams.get('name')||'');
        if(!name||name==='file')return error(400,'invalid_filename','اسم الملف غير صالح.');
        const ext=path.extname(name).slice(1).toLowerCase();
        const subjectId=safeId(url.searchParams.get('subjectId')||'')?url.searchParams.get('subjectId'):'';
        const folderId=safeId(url.searchParams.get('folderId')||'')?url.searchParams.get('folderId'):'';
        if(subjectId&&!await repository.subjectExists(auth.user_id,subjectId))return error(400,'invalid_subject','المادة المحددة غير موجودة.');
        if(folderId){const saved=await repository.readLearningState(auth.user_id);if(!(saved?.state?.folders||[]).some(folder=>folder.id===folderId))return error(400,'invalid_folder','المجلد المحدد غير موجود.');}
        const advertisedMime=String(request.headers.get('x-midad-mime')||request.headers.get('content-type')||'application/octet-stream').split(';')[0].trim().toLowerCase();
        if(!mimeOkay(ext,advertisedMime))return error(400,'mime_mismatch','نوع الملف لا يطابق امتداده.');
        const buffer=Buffer.from(await request.arrayBuffer());
        if(buffer.length>NETLIFY_MAX_UPLOAD_BYTES)return error(413,'file_too_large','الحد الأقصى للرفع على استضافة Netlify الحالية 4 ميغابايت.');
        const mime=advertisedMime==='application/octet-stream'?(MIME_BY_EXT[ext]||advertisedMime):advertisedMime;
        if(!signatureOkay(ext,buffer))return error(400,'signature','امتداد الملف لا يطابق محتواه.');
        if(ext==='txt'||ext==='md'){
          try{if(buffer.includes(0))throw new Error();new TextDecoder('utf-8',{fatal:true}).decode(buffer);}
          catch{return error(400,'invalid_text','الملف النصي ليس بترميز UTF-8 صالح.');}
        }
        const fileObject=new File([buffer],name,{type:mime});
        const policy=await validateLocalFile(fileObject,Infinity);
        if(!policy.ok)return error(400,policy.reason||'invalid_file','لم يُقبل الملف: فشل التحقق من النوع أو المحتوى.');
        const used=await repository.fileQuotaBytes(auth.user_id);
        if(used+buffer.length>USER_QUOTA_BYTES)return error(413,'storage_quota','سيتجاوز هذا الملف حد التخزين لهذا الحساب.');
        const id=randomUUID(),createdAt=now().toISOString(),key=blobKey(auth.user_id,id);
        const arrayBuffer=buffer.buffer.slice(buffer.byteOffset,buffer.byteOffset+buffer.byteLength);
        await fileStore.set(key,arrayBuffer,{metadata:{ownerId:auth.user_id,fileId:id,filename:name,mediaType:mime}});
        let row;
        try{
          row=await repository.insertFileWithinQuota({
            ownerId:auth.user_id,id,filename:name,mediaType:mime,sizeBytes:buffer.length,
            storageKey:key,previewKind:policy.previewKind||'download',folderId:folderId||null,
            subjectId:subjectId||null,createdAt,
          },USER_QUOTA_BYTES);
        }catch(e){await fileStore.delete(key).catch(()=>{});throw e;}
        if(ext==='txt'||ext==='md'){
          try{
            const text=new TextDecoder('utf-8',{fatal:true}).decode(buffer).replace(/\u0000/g,'').replace(/\r\n?/g,'\n').trim().slice(0,2_000_000);
            if(text.length<20)throw new Error('no_extractable_text');
            const chunks=makeChunks(text);
            await repository.insertTextChunks(auth.user_id,id,chunks);
            row=await repository.setFileProcessing(auth.user_id,id,{status:'ready',extractedChars:text.length,processingError:null,updatedAt:now().toISOString()});
          }catch{
            row=await repository.setFileProcessing(auth.user_id,id,{status:'failed',extractedChars:0,processingError:'processing_failed',updatedAt:now().toISOString()});
          }
        }else{
          row=await repository.setFileProcessing(auth.user_id,id,{status:'failed',extractedChars:0,processingError:'processing_unavailable',updatedAt:now().toISOString()});
        }
        await audit(auth.user_id,'file.upload','file',id,row?.status||'failed');
        return json(201,{file:safeFileRow(row)});
      }
      const contentMatch=pathName.match(/^\/api\/files\/([a-zA-Z0-9-]{1,80})\/content$/);
      const itemMatch=pathName.match(/^\/api\/files\/([a-zA-Z0-9-]{1,80})$/);
      if(contentMatch&&(method==='GET'||method==='HEAD')){
        const row=await repository.getFile(auth.user_id,contentMatch[1]);
        if(!row)return error(404,'file_not_found','الملف غير موجود.');
        if(method==='HEAD')return new Response(null,{status:200,headers:{...security,'Content-Type':row.media_type,'Content-Length':String(row.size_bytes),'Content-Disposition':`attachment; filename*=UTF-8''${attachmentName(row.filename)}`,'Cache-Control':'private, no-store'}});
        const stored=await fileStore.get(row.storage_key,{type:'arrayBuffer'});
        if(!stored)return error(404,'file_not_found','الملف غير موجود.');
        const inline=['application/pdf','image/png','image/jpeg','image/webp'].includes(row.media_type);
        return new Response(stored,{status:200,headers:{...security,'Content-Type':row.media_type,'Content-Length':String(row.size_bytes),'Content-Disposition':`${inline?'inline':'attachment'}; filename*=UTF-8''${attachmentName(row.filename)}`,'Cache-Control':'private, no-store'}});
      }
      if(itemMatch&&method==='PATCH'){
        const row=await repository.getFile(auth.user_id,itemMatch[1]);
        if(!row)return error(404,'file_not_found','الملف غير موجود.');
        const body=await readJson(16*1024);
        let filename=row.filename,favorite=Boolean(row.favorite),folderId=row.folder_id||null,subjectId=row.subject_id||null;
        if(Object.hasOwn(body,'name')){
          const next=sanitizeLocalFileName(body.name);
          if(!next||next==='file'||path.extname(next).toLowerCase()!==path.extname(row.filename).toLowerCase())return error(400,'invalid_filename','اسم الملف غير صالح؛ يجب الحفاظ على امتداده الأصلي.');
          filename=next;
        }
        if(Object.hasOwn(body,'favorite')){if(typeof body.favorite!=='boolean')return error(400,'invalid_favorite','قيمة المفضلة غير صالحة.');favorite=body.favorite;}
        if(Object.hasOwn(body,'subjectId')){subjectId=safeId(body.subjectId)?body.subjectId:null;if(subjectId&&!await repository.subjectExists(auth.user_id,subjectId))return error(400,'invalid_subject','المادة المحددة غير موجودة.');}
        if(Object.hasOwn(body,'folderId')){folderId=safeId(body.folderId)?body.folderId:null;if(folderId){const saved=await repository.readLearningState(auth.user_id);if(!(saved?.state?.folders||[]).some(folder=>folder.id===folderId))return error(400,'invalid_folder','المجلد المحدد غير موجود.');}}
        const updated=await repository.updateFile(auth.user_id,row.id,{filename,favorite,folderId,subjectId},now().toISOString());
        await audit(auth.user_id,'file.update','file',row.id,'success');
        return json(200,{file:safeFileRow(updated)});
      }
      if(itemMatch&&method==='DELETE'){
        const deleted=await repository.deleteFile(auth.user_id,itemMatch[1]);
        if(!deleted)return error(404,'file_not_found','الملف غير موجود.');
        await fileStore.delete(deleted.storage_key).catch(()=>{});
        await audit(auth.user_id,'file.delete','file',itemMatch[1],'success');
        return json(200,{ok:true});
      }
      if(pathName==='/api/ai/ask'&&method==='POST'){
        return error(503,'ai_unavailable','مساعد مِداد غير مفعّل على نسخة Netlify هذه. لن نرسل السؤال أو نخمن إجابة.');
      }
      if(pathName==='/api/admin/overview'&&method==='GET'){
        if(auth.role!=='admin')return error(403,'admin_required','هذه الصفحة متاحة للإدارة فقط.');
        return json(200,await repository.adminOverview());
      }
      return error(404,'not_found','المسار غير موجود.');
    }catch(e){
      if(e?.status===413||e?.message==='body_too_large')return error(413,'body_too_large','حجم الطلب أكبر من الحد المسموح.');
      if(e?.message==='storage_quota')return error(413,'storage_quota','سيتجاوز هذا الملف حد التخزين لهذا الحساب.');
      if(e?.message==='invalid_json')return error(400,'invalid_json','صيغة الطلب غير صالحة.');
      if(e?.message==='invalid_state')return error(400,'invalid_state','تعذر حفظ بيانات التعلّم.');
      console.error('MIDAD Netlify API request failed.');
      return error(500,'internal_error','تعذّر تنفيذ الطلب الآن.');
    }
  };
}
