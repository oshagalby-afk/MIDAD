CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  email TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'student' CHECK (role IN ('student','teacher','admin')),
  email_verified BOOLEAN NOT NULL DEFAULT FALSE,
  disabled BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL,
  last_login_at TIMESTAMPTZ
);
CREATE UNIQUE INDEX IF NOT EXISTS users_email_lower_idx ON users (lower(email));

CREATE TABLE IF NOT EXISTS profiles (
  user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  username TEXT,
  display_name TEXT NOT NULL DEFAULT '',
  locale TEXT NOT NULL DEFAULT 'ar' CHECK (locale IN ('ar','en')),
  created_at TIMESTAMPTZ NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS profiles_username_lower_idx
  ON profiles (lower(username)) WHERE username IS NOT NULL;

CREATE TABLE IF NOT EXISTS sessions (
  token_hash TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  csrf_hash TEXT NOT NULL,
  expires_at TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ NOT NULL
);
CREATE INDEX IF NOT EXISTS sessions_user_expiry_idx ON sessions (user_id, expires_at);

CREATE TABLE IF NOT EXISTS learning_state (
  user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  state_json JSONB NOT NULL,
  revision BIGINT NOT NULL DEFAULT 1,
  updated_at TIMESTAMPTZ NOT NULL
);

CREATE TABLE IF NOT EXISTS files (
  owner_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  id TEXT NOT NULL,
  filename TEXT NOT NULL,
  media_type TEXT NOT NULL,
  size_bytes BIGINT NOT NULL CHECK (size_bytes > 0),
  status TEXT NOT NULL CHECK (status IN ('uploading','processing','ready','failed')),
  storage_key TEXT NOT NULL,
  preview_kind TEXT NOT NULL DEFAULT 'download',
  favorite BOOLEAN NOT NULL DEFAULT FALSE,
  folder_id TEXT,
  subject_id TEXT,
  extracted_chars INTEGER NOT NULL DEFAULT 0,
  processing_error TEXT,
  created_at TIMESTAMPTZ NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL,
  PRIMARY KEY (owner_id,id),
  UNIQUE (owner_id,storage_key)
);
CREATE INDEX IF NOT EXISTS files_owner_status_idx ON files (owner_id,status,created_at DESC);

CREATE TABLE IF NOT EXISTS file_chunks (
  owner_id TEXT NOT NULL,
  file_id TEXT NOT NULL,
  chunk_no INTEGER NOT NULL,
  page_no INTEGER,
  section TEXT,
  content TEXT NOT NULL,
  PRIMARY KEY (owner_id,file_id,chunk_no),
  FOREIGN KEY (owner_id,file_id) REFERENCES files(owner_id,id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS file_chunks_lookup_idx ON file_chunks (owner_id,file_id,page_no);

CREATE TABLE IF NOT EXISTS search_history (
  owner_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  id TEXT NOT NULL,
  query_hash TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL,
  PRIMARY KEY (owner_id,id)
);

CREATE TABLE IF NOT EXISTS rate_limits (
  scope TEXT NOT NULL,
  subject TEXT NOT NULL,
  bucket BIGINT NOT NULL,
  hits INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (scope,subject,bucket)
);
CREATE INDEX IF NOT EXISTS rate_limits_bucket_idx ON rate_limits (bucket);

CREATE TABLE IF NOT EXISTS audit_logs (
  id TEXT PRIMARY KEY,
  actor_id TEXT REFERENCES users(id) ON DELETE SET NULL,
  action TEXT NOT NULL,
  resource_type TEXT,
  resource_id TEXT,
  outcome TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL
);
CREATE INDEX IF NOT EXISTS audit_owner_date_idx ON audit_logs (actor_id,created_at);
