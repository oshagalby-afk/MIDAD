import test from 'node:test';
import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { existsSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../..');

test('Netlify static build publishes only the explicit public shell',()=>{
  execFileSync(process.execPath,['scripts/build-netlify.mjs'],{cwd:root,stdio:'pipe'});
  const dist=path.join(root,'dist');
  for(const name of ['index.html','styles.css','app.js','bootstrap.mjs','file-policy.mjs','icon.svg','manifest.webmanifest','sw.js','_headers']){
    assert.equal(existsSync(path.join(dist,name)),true,`expected public asset ${name}`);
  }
  for(const name of ['server.mjs','database.mjs','ai-service.mjs','security.test.mjs','.env.example','netlify.toml']){
    assert.equal(existsSync(path.join(dist,name)),false,`server/source file leaked: ${name}`);
  }
});
