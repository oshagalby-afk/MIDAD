import test from 'node:test';
import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import { call, makeHarness, register } from './helpers.mjs';

async function withHarness(t) {
  const harness=await makeHarness();
  t.after(()=>harness.close());
  return harness;
}

test('Netlify API registers student accounts, keeps CSRF stable, and persists learning state in PostgreSQL',async t=>{
  const h=await withHarness(t);
  const user=await register(h);
  assert.equal(user.response.status,201);
  assert.equal(user.data.user.role,'student');
  assert.equal(user.data.emailVerified,false);
  assert.match(user.response.headers.get('set-cookie'),/HttpOnly/);
  assert.match(user.response.headers.get('set-cookie'),/SameSite=Strict/);
  assert.match(user.response.headers.get('set-cookie'),/Secure/);

  const session=await call(h,'/api/auth/session',{cookie:user.cookie});
  assert.equal(session.status,200);
  const sessionData=await session.json();
  assert.equal(sessionData.authenticated,true);
  assert.equal(sessionData.csrfToken,user.data.csrfToken);
  const otherTab=await call(h,'/api/auth/session',{cookie:user.cookie});
  assert.equal((await otherTab.json()).csrfToken,sessionData.csrfToken);

  const state={
    schema:1,preferences:{lang:'ar',theme:'dark'},
    subjects:[{id:'sub-1',name:'Neurobiology'}],
    lectures:[{id:'lec-1',subjectId:'sub-1',title:'Synapses'}],
    notes:[{id:'note-1',subjectId:'sub-1',title:'Week 1',body:'Neuron structure'}],
    cards:[],questions:[],tasks:[],sessions:[],quizAttempts:[],reviewHistory:[],
    folders:[{id:'folder-1',name:'Exam'}],activeQuiz:null,timer:null,aiConversations:[],
  };
  const saved=await call(h,'/api/learning/state',{method:'PUT',cookie:user.cookie,csrf:sessionData.csrfToken,body:state});
  assert.equal(saved.status,200);
  assert.equal((await saved.json()).revision,1);
  const fetched=await call(h,'/api/learning/state',{cookie:user.cookie});
  const fetchedData=await fetched.json();
  assert.equal(fetchedData.state.subjects[0].name,'Neurobiology');
  assert.equal(fetchedData.state.preferences.theme,'dark');
});

test('mutations reject missing CSRF and cross-origin requests without changing stored state',async t=>{
  const h=await withHarness(t);
  const user=await register(h);
  const deniedNoCsrf=await call(h,'/api/learning/state',{method:'PUT',cookie:user.cookie,body:{subjects:[{id:'attacker',name:'No'}]}});
  assert.equal(deniedNoCsrf.status,403);
  const deniedScheme=await call(h,'/api/profile',{method:'PATCH',cookie:user.cookie,csrf:user.data.csrfToken,origin:'http://midad.test',body:{displayName:'Changed'}});
  assert.equal(deniedScheme.status,403);
  const deniedOrigin=await call(h,'/api/profile',{method:'PATCH',cookie:user.cookie,csrf:user.data.csrfToken,origin:'https://attacker.invalid',body:{displayName:'Changed'}});
  assert.equal(deniedOrigin.status,403);
  const read=await call(h,'/api/learning/state',{cookie:user.cookie});
  assert.deepEqual((await read.json()).state.subjects,[]);
});

test('PostgreSQL enforces case-insensitive usernames and username sign-in',async t=>{
  const h=await withHarness(t);
  const user=await register(h,{username:'A132008'});
  assert.equal(user.response.status,201);
  const duplicate=await register(h,{email:`other-${randomUUID()}@example.invalid`,username:'a132008'});
  assert.equal(duplicate.response.status,409);
  assert.equal(duplicate.data.error,'username_taken');
  const login=await call(h,'/api/auth/login',{method:'POST',body:{identifier:'a132008',password:user.password}});
  assert.equal(login.status,200);
  assert.equal((await login.json()).user.username,'A132008');
});

test('private Blobs-backed file metadata and contents are owner-scoped; text files are indexed',async t=>{
  const h=await withHarness(t);
  const owner=await register(h);
  const other=await register(h,{email:`other-${randomUUID()}@example.invalid`,username:`other-${randomUUID().slice(0,8)}`});
  const initialSession=await (await call(h,'/api/auth/session',{cookie:owner.cookie})).json();
  const state={schema:1,preferences:{lang:'ar',theme:'light'},subjects:[{id:'sub-1',name:'Biology'}],lectures:[],notes:[],cards:[],questions:[],tasks:[],sessions:[],quizAttempts:[],reviewHistory:[],folders:[{id:'folder-1',name:'Class'}],activeQuiz:null,timer:null,aiConversations:[]};
  const saved=await call(h,'/api/learning/state',{method:'PUT',cookie:owner.cookie,csrf:initialSession.csrfToken,body:state});
  assert.equal(saved.status,200);
  const text=Buffer.from('Neurons communicate using synaptic signals and receptor responses. '.repeat(2));
  const params=new URLSearchParams({name:'neuro.txt',subjectId:'sub-1',folderId:'folder-1'});
  const upload=await call(h,`/api/files/upload?${params}`,{method:'POST',cookie:owner.cookie,csrf:initialSession.csrfToken,headers:{'Content-Type':'text/plain','X-Midad-Mime':'text/plain'},body:text});
  assert.equal(upload.status,201);
  const {file}=await upload.json();
  assert.equal(file.status,'ready');
  assert.ok(file.extractedChars>20);
  assert.equal(file.folderId,'folder-1');

  const ownerList=await call(h,'/api/files',{cookie:owner.cookie});
  assert.equal((await ownerList.json()).files.length,1);
  const otherList=await call(h,'/api/files',{cookie:other.cookie});
  assert.deepEqual((await otherList.json()).files,[]);
  const ownContent=await call(h,`/api/files/${file.id}/content`,{cookie:owner.cookie});
  assert.equal(ownContent.status,200);
  assert.equal(Buffer.from(await ownContent.arrayBuffer()).toString(),text.toString());
  const intruder=await call(h,`/api/files/${file.id}/content`,{cookie:other.cookie});
  assert.equal(intruder.status,404);

  const search=await call(h,'/api/search?q=neurons',{cookie:owner.cookie});
  assert.equal(search.status,200);
  assert.ok((await search.json()).results.some(row=>row.id===file.id));

  const update=await call(h,`/api/files/${file.id}`,{method:'PATCH',cookie:owner.cookie,csrf:initialSession.csrfToken,body:{name:'neuro-renamed.txt',favorite:true}});
  assert.equal(update.status,200);
  assert.equal((await update.json()).file.favorite,true);
  const denied=await call(h,`/api/files/${file.id}`,{method:'DELETE',cookie:other.cookie,csrf:other.data.csrfToken});
  assert.equal(denied.status,404);
  const deleted=await call(h,`/api/files/${file.id}`,{method:'DELETE',cookie:owner.cookie,csrf:initialSession.csrfToken});
  assert.equal(deleted.status,200);
  assert.equal(h.objects.size,0);
});

test('Netlify upload cap rejects oversized binary before touching Blob storage',async t=>{
  const h=await withHarness(t);
  const user=await register(h);
  const health=await call(h,'/api/health');
  assert.equal((await health.json()).uploadMaxBytes,4*1024*1024);
  const oversized=Buffer.alloc(4*1024*1024+1,0x61);
  const response=await call(h,'/api/files/upload?name=notes.txt',{method:'POST',cookie:user.cookie,csrf:user.data.csrfToken,headers:{'Content-Type':'text/plain','X-Midad-Mime':'text/plain'},body:oversized});
  assert.equal(response.status,413);
  assert.equal((await response.json()).error,'file_too_large');
  assert.equal(h.objects.size,0);
});

test('unverified sign-up cannot become admin and account data stays isolated',async t=>{
  const h=await withHarness(t);
  const user=await register(h);
  const admin=await call(h,'/api/admin/overview',{cookie:user.cookie});
  assert.equal(admin.status,403);
  const unauthenticated=await call(h,'/api/files');
  assert.equal(unauthenticated.status,401);
});

test('AI is fail-closed on Netlify and health never claims it is configured',async t=>{
  const h=await withHarness(t);
  const user=await register(h);
  const health=await call(h,'/api/health');
  assert.equal((await health.json()).aiConfigured,false);
  const answer=await call(h,'/api/ai/ask',{method:'POST',cookie:user.cookie,csrf:user.data.csrfToken,body:{prompt:'Explain confidential notes'}});
  assert.equal(answer.status,503);
  assert.equal((await answer.json()).error,'ai_unavailable');
  const count=await h.database.query('SELECT COUNT(*)::integer AS count FROM audit_logs WHERE action LIKE $1',['%ai%']);
  assert.equal(count.rows[0].count,0);
});

test('PDF bytes remain private and downloadable but are explicitly not extracted on Netlify',async t=>{
  const h=await withHarness(t);
  const user=await register(h);
  const pdf=Buffer.from('%PDF-1.7\n1 0 obj << /Type /Catalog >> endobj\n%%EOF\n');
  const upload=await call(h,'/api/files/upload?name=sample.pdf',{method:'POST',cookie:user.cookie,csrf:user.data.csrfToken,headers:{'Content-Type':'application/pdf','X-Midad-Mime':'application/pdf'},body:pdf});
  assert.equal(upload.status,201);
  const {file}=await upload.json();
  assert.equal(file.status,'failed');
  assert.equal(file.processingError,'processing_unavailable');
  const content=await call(h,`/api/files/${file.id}/content`,{cookie:user.cookie});
  assert.equal(content.status,200);
  assert.equal(content.headers.get('content-type'),'application/pdf');
  assert.deepEqual(Buffer.from(await content.arrayBuffer()),pdf);
});
