import { readFile } from 'node:fs/promises';
import { PGlite } from '@electric-sql/pglite';
import { createMidadApi } from '../api.mjs';
import { createPostgresRepository } from '../repository.mjs';

const migration = await readFile(new URL('../database/migrations/0001_core.sql', import.meta.url), 'utf8');

export async function makeHarness() {
  const database = new PGlite();
  await database.exec(migration);
  const pool = {
    query: (...args) => database.query(...args),
    async connect() {
      return { query: (...args) => database.query(...args), release() {} };
    },
  };
  const repository = createPostgresRepository(pool);
  const objects = new Map();
  const fileStore = {
    async set(key, value, options={}) {
      const bytes = Buffer.from(value);
      objects.set(key, { bytes:Buffer.from(bytes), metadata:options.metadata||{} });
      return { modified:true, etag:'local-etag' };
    },
    async get(key, options={}) {
      const entry=objects.get(key);
      if(!entry)return null;
      if(options.type==='arrayBuffer')return entry.bytes.buffer.slice(entry.bytes.byteOffset,entry.bytes.byteOffset+entry.bytes.byteLength);
      return entry.bytes.toString('utf8');
    },
    async delete(key) { objects.delete(key); },
  };
  let instant = new Date('2026-10-07T17:00:00.000Z');
  const handler=createMidadApi({
    repository,fileStore,
    clock:()=>new Date(instant),
    getIp:(_request,context)=>context?.ip||'198.51.100.10',
  });
  return { database,pool,repository,fileStore,objects,handler,setNow:value=>{instant=new Date(value);},close:()=>database.close() };
}

export function makeRequest(path,{method='GET',body,headers={},origin='https://midad.test',cookie,csrf,ip='198.51.100.10'}={}) {
  const requestHeaders=new Headers(headers);
  if(origin!==null)requestHeaders.set('Origin',origin);
  if(cookie)requestHeaders.set('Cookie',cookie);
  if(csrf)requestHeaders.set('X-CSRF-Token',csrf);
  let payload=body;
  if(body!==undefined&&body!==null&&typeof body==='object'&&!Buffer.isBuffer(body)&&!(body instanceof Uint8Array)&&!(body instanceof Blob)){
    requestHeaders.set('Content-Type','application/json');
    payload=JSON.stringify(body);
  }
  return {request:new Request(`https://midad.test${path}`,{method,headers:requestHeaders,body:method==='GET'||method==='HEAD'?undefined:payload}),context:{ip}};
}

export async function call(harness,path,options={}) {
  const {request,context}=makeRequest(path,options);
  return harness.handler(request,context);
}

export async function register(harness,{email=`user-${crypto.randomUUID()}@example.invalid`,username=`student-${crypto.randomUUID().slice(0,8)}`,password='test-only-password-that-is-long-52',displayName='MIDAD Test',ip='198.51.100.10'}={}) {
  const response=await call(harness,'/api/auth/register',{method:'POST',body:{email,username,password,displayName},ip});
  const data=await response.json();
  const cookie=response.headers.get('set-cookie')?.split(';')[0]||'';
  return {response,data,cookie,email,username,password};
}
