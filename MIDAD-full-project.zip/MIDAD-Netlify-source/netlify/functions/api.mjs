import pg from 'pg';
import { getConnectionString } from '@netlify/database';
import { getStore } from '@netlify/blobs';
import { createMidadApi } from '../api.mjs';
import { createPostgresRepository } from '../repository.mjs';

const { Pool } = pg;
let resourcesPromise;

async function getHandler() {
  if (!resourcesPromise) {
    resourcesPromise = (async () => {
      const pool = new Pool({
        connectionString: getConnectionString(),
        max: 2,
        idleTimeoutMillis: 5000,
        connectionTimeoutMillis: 5000,
        allowExitOnIdle: true,
      });
      const store = getStore({ name: 'midad-private-files', consistency: 'strong' });
      const repository = createPostgresRepository(pool);
      return { pool, handler: createMidadApi({ repository, fileStore: store }) };
    })().catch(error => {
      resourcesPromise = null;
      throw error;
    });
  }
  return resourcesPromise;
}

export default async function handler(request, context) {
  try {
    const resources = await getHandler();
    return await resources.handler(request, context);
  } catch {
    return Response.json(
      { error: 'backend_unavailable', message: 'الخدمة غير جاهزة؛ تحقق من ربط قاعدة البيانات والتخزين المُدارين.' },
      { status: 503, headers: { 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' } },
    );
  }
}

export const config = { path: '/api/*' };
