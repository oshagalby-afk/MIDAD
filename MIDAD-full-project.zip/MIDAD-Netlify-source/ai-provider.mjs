const DEFAULT_MODEL = 'gpt-5-mini';

function endpoint(base) {
  if (!base) throw new Error('ai_not_configured');
  const normalized = base.endsWith('/') ? base : `${base}/`;
  return new URL('chat/completions', normalized).toString();
}

export async function completeWithProvider({ messages, maxTokens = 1600, jsonSchema = null, model = process.env.MIDAD_AI_MODEL || DEFAULT_MODEL }) {
  const key = process.env.OPENAI_API_KEY;
  const base = process.env.OPENAI_API_BASE || process.env.OPENAI_BASE_URL;
  if (!key || !base) throw new Error('ai_not_configured');
  if (process.env.MIDAD_AI_PROVIDER && process.env.MIDAD_AI_PROVIDER !== 'openai-compatible') throw new Error('provider_not_supported');

  const payload = {
    model,
    messages,
    max_completion_tokens: Math.max(128, Math.min(5000, Number(maxTokens) || 1600)),
    reasoning: { effort: 'minimal' },
  };
  if (jsonSchema) payload.response_format = {
    type: 'json_schema',
    json_schema: { name: jsonSchema.name, strict: true, schema: jsonSchema.schema },
  };

  let lastError;
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      const response = await fetch(endpoint(base), {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${key}`, 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
        signal: AbortSignal.timeout(30000),
      });
      if (!response.ok) {
        if (attempt === 0 && (response.status === 429 || response.status >= 500)) {
          await new Promise(resolve => setTimeout(resolve, 500));
          continue;
        }
        throw new Error(`ai_http_${response.status}`);
      }
      const result = await response.json();
      const content = result?.choices?.[0]?.message?.content;
      if (typeof content !== 'string' || !content.trim()) throw new Error('ai_empty_response');
      return {
        content,
        model: String(result.model || model),
        usage: {
          inputTokens: Math.max(0, Number(result.usage?.prompt_tokens) || 0),
          outputTokens: Math.max(0, Number(result.usage?.completion_tokens) || 0),
        },
      };
    } catch (error) {
      lastError = error;
      if (attempt === 0 && (error.name === 'TimeoutError' || error.name === 'TypeError')) {
        await new Promise(resolve => setTimeout(resolve, 400));
        continue;
      }
      break;
    }
  }
  throw lastError || new Error('ai_unavailable');
}
