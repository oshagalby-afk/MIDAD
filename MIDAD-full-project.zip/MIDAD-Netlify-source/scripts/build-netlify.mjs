import { cp, mkdir, rm } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const output = path.join(root, 'dist');
const publicFiles = [
  'index.html', 'styles.css', 'app.js', 'bootstrap.mjs', 'file-policy.mjs',
  'icon.svg', 'manifest.webmanifest', 'sw.js', '_headers',
];

await rm(output, { recursive: true, force: true });
await mkdir(output, { recursive: true });
for (const file of publicFiles) {
  await cp(path.join(root, file), path.join(output, file));
}
console.log(`Netlify static shell built: ${publicFiles.length} public assets -> dist/`);
