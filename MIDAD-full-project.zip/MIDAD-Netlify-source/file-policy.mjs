const MAX_FILE_BYTES = 50 * 1024 * 1024;
const MAX_TEXT_PREVIEW_BYTES = 2 * 1024 * 1024;
const ALLOWED_EXTENSIONS = new Set([
  'pdf', 'doc', 'docx', 'ppt', 'pptx', 'txt', 'md',
  'png', 'jpg', 'jpeg', 'webp', 'mp3', 'wav', 'mp4', 'mov'
]);
const ACTIVE_EXTENSIONS = new Set([
  'html', 'htm', 'xhtml', 'svg', 'xml', 'js', 'mjs', 'cjs', 'wasm',
  'exe', 'dll', 'com', 'bat', 'cmd', 'ps1', 'sh', 'jar', 'hta', 'url', 'lnk'
]);

export function sanitizeLocalFileName(input) {
  let name = String(input ?? 'file').normalize('NFKC');
  name = name.replace(/[\\/]+/g, '_').replace(/[\u0000-\u001f\u007f]/g, '').trim();
  name = name.replace(/^\.+/, '').replace(/\s+/g, ' ').slice(0, 180);
  return name || 'file';
}

function extensionOf(name) {
  const safe = sanitizeLocalFileName(name);
  const index = safe.lastIndexOf('.');
  return index < 0 ? '' : safe.slice(index + 1).toLowerCase();
}

function matchesSignature(ext, bytes) {
  const starts = (...values) => values.every((value, i) => bytes[i] === value);
  if (ext === 'pdf') return bytes.length >= 5 && starts(0x25, 0x50, 0x44, 0x46, 0x2d);
  if (ext === 'png') return bytes.length >= 8 && starts(0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a);
  if (ext === 'jpg' || ext === 'jpeg') return bytes.length >= 3 && starts(0xff, 0xd8, 0xff);
  if (ext === 'webp') return bytes.length >= 12 && starts(0x52, 0x49, 0x46, 0x46) && bytes[8] === 0x57 && bytes[9] === 0x45 && bytes[10] === 0x42 && bytes[11] === 0x50;
  return true;
}

export async function validateLocalFile(file, availableBytes = Infinity) {
  if (!file || typeof file !== 'object' || typeof file.size !== 'number' || typeof file.slice !== 'function') return { ok: false, reason: 'invalid' };
  const name = sanitizeLocalFileName(file.name);
  const ext = extensionOf(name);
  if (!name || !ext || !Number.isFinite(file.size) || file.size <= 0) return { ok: false, reason: 'empty' };
  if (ACTIVE_EXTENSIONS.has(ext)) return { ok: false, reason: 'active_type' };
  if (!ALLOWED_EXTENSIONS.has(ext)) return { ok: false, reason: 'invalid' };
  if (file.size > MAX_FILE_BYTES) return { ok: false, reason: 'too_large' };
  if (Number.isFinite(availableBytes) && availableBytes < file.size) return { ok: false, reason: 'quota' };

  const signatureKinds = { pdf: 'pdf', png: 'image', jpg: 'image', jpeg: 'image', webp: 'image' };
  if (signatureKinds[ext]) {
    try {
      const header = new Uint8Array(await file.slice(0, 16).arrayBuffer());
      if (!matchesSignature(ext, header)) return { ok: false, reason: 'signature' };
    } catch {
      return { ok: false, reason: 'invalid' };
    }
    return { ok: true, previewKind: signatureKinds[ext] };
  }

  if (ext === 'txt' || ext === 'md') {
    if (file.size > MAX_TEXT_PREVIEW_BYTES) return { ok: true, previewKind: 'download' };
    try {
      const bytes = new Uint8Array(await file.arrayBuffer());
      if (bytes.includes(0)) return { ok: false, reason: 'binary_text' };
      new TextDecoder('utf-8', { fatal: true }).decode(bytes);
      return { ok: true, previewKind: 'text' };
    } catch {
      return { ok: false, reason: 'binary_text' };
    }
  }

  return { ok: true, previewKind: 'download' };
}
