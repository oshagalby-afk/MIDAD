import { spawnSync } from 'node:child_process';
import path from 'node:path';

const OFFICE_EXTRACT = String.raw`
import re, sys, zipfile, xml.etree.ElementTree as ET
p, ext = sys.argv[1], sys.argv[2]
with zipfile.ZipFile(p) as z:
    names = z.namelist()
    if ext == 'docx':
        selected = ['word/document.xml'] if 'word/document.xml' in names else []
    else:
        selected = sorted((n for n in names if re.fullmatch(r'ppt/slides/slide\d+\.xml', n)), key=lambda n: int(re.search(r'(\d+)\.xml$', n).group(1)))
    if not selected: raise SystemExit(4)
    total = sum(z.getinfo(n).file_size for n in selected)
    if total > 25 * 1024 * 1024: raise SystemExit(5)
    for i, name in enumerate(selected, 1):
        raw = z.read(name)
        if len(raw) > 5 * 1024 * 1024: raise SystemExit(5)
        root = ET.fromstring(raw)
        text = ' '.join((e.text or '').strip() for e in root.iter() if e.tag.endswith('}t') and (e.text or '').strip())
        if text: print(f'\n\f\n{text}')
`;

function run(command, args, options = {}) {
  const result = spawnSync(command, args, { encoding: 'utf8', timeout: 25000, maxBuffer: 26 * 1024 * 1024, ...options });
  if (result.error) throw new Error(result.error.code === 'ETIMEDOUT' ? 'processing_timeout' : 'processing_unavailable');
  if (result.status !== 0) throw new Error(result.status === 4 ? 'unsupported_office_content' : result.status === 5 ? 'office_content_too_large' : 'processing_failed');
  return result.stdout || '';
}

export function normalizeExtractedText(raw) {
  return String(raw || '').replace(/\u0000/g, '').replace(/\r\n?/g, '\n').replace(/[\t ]+\n/g, '\n').replace(/\n{4,}/g, '\n\n\n').trim().slice(0, 2_000_000);
}

export function extractDocument(filename, filePath, buffer) {
  const ext = path.extname(filename).slice(1).toLowerCase();
  let raw = '';
  if (ext === 'txt' || ext === 'md') raw = new TextDecoder('utf-8', { fatal: true }).decode(buffer);
  else if (ext === 'pdf') raw = run('pdftotext', ['-layout', '-enc', 'UTF-8', filePath, '-']);
  else if (ext === 'docx' || ext === 'pptx') raw = run('python3', ['-c', OFFICE_EXTRACT, filePath, ext]);
  else if (ext === 'doc' || ext === 'ppt') throw new Error('legacy_office_not_extractable');
  else throw new Error('format_not_text_extractable');
  const text = normalizeExtractedText(raw);
  if (text.length < 20) throw new Error('no_extractable_text');
  const pages = text.split('\f').map(x => x.trim()).filter(Boolean);
  const sections = pages.length > 1 ? pages.map((content, i) => ({ page: i + 1, content })) : [{ page: null, content: text }];
  return { text, sections };
}

export function makeChunks(sections, { chunkSize = 1200, overlap = 160, maxChunks = 5000 } = {}) {
  const chunks = [];
  for (const section of sections) {
    const text = section.content;
    if (!text) continue;
    let start = 0;
    while (start < text.length && chunks.length < maxChunks) {
      let end = Math.min(text.length, start + chunkSize);
      if (end < text.length) {
        const boundary = text.lastIndexOf('\n', end);
        if (boundary > start + chunkSize * 0.65) end = boundary;
      }
      const content = text.slice(start, end).trim();
      if (content) chunks.push({ page: section.page ?? null, section: '', content });
      if (end >= text.length) break;
      start = Math.max(start + 1, end - overlap);
    }
  }
  return chunks;
}
