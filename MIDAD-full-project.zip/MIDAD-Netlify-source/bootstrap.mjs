const STORAGE_KEY='midad-local-v1';
const DEFAULT_STATE={schema:1,preferences:{lang:'ar',theme:'light'},subjects:[],lectures:[],notes:[],cards:[],questions:[],tasks:[],sessions:[],quizAttempts:[],reviewHistory:[],folders:[],activeQuiz:null,timer:null,aiConversations:[]};
const words={
  ar:{brand:'مِداد',tag:'مساحتك الآمنة للتعلّم',login:'تسجيل الدخول',register:'إنشاء حساب',email:'البريد الإلكتروني',username:'اسم المستخدم',identifier:'البريد الإلكتروني أو اسم المستخدم',password:'كلمة المرور',name:'الاسم الظاهر',submitLogin:'دخول آمن',submitRegister:'إنشاء الحساب',switchRegister:'ليس لديك حساب؟ أنشئ حسابًا',switchLogin:'لديك حساب بالفعل؟ سجّل الدخول',notice:'لن يرسل هذا العرض رسالة تحقق عبر البريد؛ خدمة البريد لم تُربط بعد.',secure:'كلمة المرور تُحفظ بتجزئة مشفّرة على الخادم ولا تُحفظ في المتصفح.',loading:'نتحقق من الجلسة…',sessionError:'تعذر الاتصال بخادم مِداد. تحقق من الاتصال ثم أعد المحاولة.',retry:'إعادة المحاولة',announcement:'صُنعت بحب | أحمد عبد الحكم | 01205099425',copyright:'حقوق محفوظة © 2026 العبيدي',logout:'هل تريد تسجيل الخروج من حسابك؟',logoutError:'تعذر إنهاء الجلسة الآن. حاول مرة أخرى.',syncError:'تعذر مزامنة آخر تغيير مع الخادم؛ احتُفظ بنسخة على هذا الجهاز مؤقتًا.',registerError:'تعذر إنشاء الحساب. تحقق من البيانات وحاول مرة أخرى.',loginError:'البريد أو اسم المستخدم أو كلمة المرور غير صحيحة.',nameRequired:'أدخل الاسم الظاهر.',usernameRequired:'اختر اسم مستخدم.',usernamePolicy:'اسم المستخدم من 3 إلى 32 حرفًا أو رقمًا، ويسمح بالنقطة والشرطة والواصلة.',usernameTaken:'اسم المستخدم مستخدم بالفعل.',emailRequired:'أدخل بريدًا إلكترونيًا صالحًا.',passwordPolicy:'كلمة المرور يجب أن تكون من 12 إلى 128 حرفًا.',accountExists:'يوجد حساب بهذا البريد بالفعل.',created:'تم إنشاء الحساب وتسجيل الدخول.',signedIn:'تم تسجيل الدخول.',serviceNotice:'مساعد الذكاء غير مهيأ في هذا الخادم. لن نعرض إجابة بديلة أو مصطنعة.'},
  en:{brand:'MIDAD',tag:'Your private learning space',login:'Sign in',register:'Create account',email:'Email address',username:'Username',identifier:'Email or username',password:'Password',name:'Display name',submitLogin:'Sign in securely',submitRegister:'Create account',switchRegister:'New to MIDAD? Create an account',switchLogin:'Already have an account? Sign in',notice:'This preview does not send email verification messages; an email provider is not connected yet.',secure:'Your password is stored as a salted hash on the server and is not saved in browser storage.',loading:'Checking your session…',sessionError:'Could not reach the MIDAD server. Check the connection and retry.',retry:'Retry',announcement:'Made with care | Ahmad Abdilhkm | 01205099425',copyright:'Copyright © 2026 Al-Obaidi',logout:'Sign out of your account?',logoutError:'Could not sign out right now. Please try again.',syncError:'The latest change could not sync; a local device copy was retained temporarily.',registerError:'Could not create the account. Check the fields and try again.',loginError:'Email, username or password is incorrect.',nameRequired:'Enter a display name.',usernameRequired:'Choose a username.',usernamePolicy:'Username must be 3–32 characters: letters, numbers, dot, underscore or hyphen.',usernameTaken:'That username is already in use.',emailRequired:'Enter a valid email address.',passwordPolicy:'Password must contain 12–128 characters.',accountExists:'An account with this email already exists.',created:'Account created and signed in.',signedIn:'Signed in.',serviceNotice:'AI is not configured on this server. No substitute or invented answer will be shown.'},
};
let locale=localStorage.getItem('midad-ui-lang')==='en'?'en':'ar';
let authMode='register';
let auth=null;
let syncTimer=0;
let pendingState='';
let syncQueue=Promise.resolve();
let syncAdapterInstalled=false;
const $=(q,root=document)=>root.querySelector(q);
const copy=()=>words[locale];
function setLocale(next){locale=next==='en'?'en':'ar';localStorage.setItem('midad-ui-lang',locale);document.documentElement.lang=locale;document.documentElement.dir=locale==='ar'?'rtl':'ltr';updateAnnouncement();if($('#authGate'))renderGate($('#authMessage')?.textContent||'');}
function updateAnnouncement(){const el=$('#midadAnnouncementText');if(el)el.textContent=copy().announcement;}
function api(path,options={}){
  const method=String(options.method||'GET').toUpperCase();
  const headers=new Headers(options.headers||{});
  let body=options.body;
  if(body!==undefined&&typeof body!=='string'&&!(body instanceof FormData)&&!(body instanceof Blob)){headers.set('Content-Type','application/json');body=JSON.stringify(body);}
  if(!['GET','HEAD','OPTIONS'].includes(method)&&auth?.csrf)headers.set('X-CSRF-Token',auth.csrf);
  return fetch(path,{method,headers,body,credentials:'same-origin',cache:'no-store',keepalive:Boolean(options.keepalive)}).then(async response=>{
    let data={};try{data=await response.json()}catch{}
    if(!response.ok){const error=new Error(data.message||copy().sessionError);error.status=response.status;error.code=data.error;throw error;}
    return data;
  });
}
function mountChrome(){
  let bar=$('#midadAnnouncement');
  if(!bar){bar=document.createElement('div');bar.id='midadAnnouncement';bar.className='announcement-bar';bar.setAttribute('role','note');bar.innerHTML='<span id="midadAnnouncementText"></span>';document.body.prepend(bar);}
  updateAnnouncement();
  const footer=$('.app-footer');
  if(footer){footer.innerHTML=`<span>${copy().brand} <span class="footer-sep">·</span> <span>${copy().tag}</span></span><span class="footer-copyright">${copy().copyright}</span>`;}
  const direction=locale==='ar'?'rtl':'ltr';
  if(document.documentElement.lang!==locale)document.documentElement.lang=locale;
  if(document.documentElement.dir!==direction)document.documentElement.dir=direction;
}
function renderGate(message='',{preserveFields=true}={}){
  let root=$('#authGate');
  if(!root){root=document.createElement('section');root.id='authGate';root.className='auth-gate';root.setAttribute('aria-labelledby','authHeading');const shell=$('.app-shell');document.body.insertBefore(root,shell||$('#midadAnnouncement')?.nextSibling||document.body.firstChild);}
  const oldForm=preserveFields?$('#midadAuthForm',root):null;
  const savedValues=oldForm?Object.fromEntries(new FormData(oldForm).entries()):{};
  const focusedName=oldForm&&oldForm.contains(document.activeElement)?document.activeElement.name:'';
  const w=copy();
  root.innerHTML=`<div class="auth-card"><div class="auth-brand"><span class="auth-mark">م</span><div><b>${w.brand}</b><small>MIDAD</small></div></div><h1 id="authHeading">${authMode==='register'?w.register:w.login}</h1><p class="auth-tagline">${w.tag}</p><p id="authMessage" class="auth-message" role="status" aria-live="polite">${message}</p><form id="midadAuthForm" autocomplete="on">
    ${authMode==='register'?`<label class="auth-field">${w.name}<input name="displayName" type="text" maxlength="80" autocomplete="name" required></label>`:''}
    ${authMode==='register'?`<label class="auth-field">${w.username}<input name="username" type="text" minlength="3" maxlength="32" pattern="[A-Za-z0-9][A-Za-z0-9_.\\-]{2,31}" autocomplete="username" required></label>`:''}
    ${authMode==='register'?`<label class="auth-field">${w.email}<input name="email" type="email" maxlength="254" autocomplete="email" inputmode="email" required></label>`:`<label class="auth-field">${w.identifier}<input name="identifier" type="text" maxlength="254" autocomplete="username" required></label>`}
    <label class="auth-field">${w.password}<input name="password" type="password" minlength="${authMode==='register'?12:1}" maxlength="128" autocomplete="${authMode==='register'?'new-password':'current-password'}" required></label><button class="primary-button auth-submit" type="submit">${authMode==='register'?w.submitRegister:w.submitLogin}</button></form><button class="auth-switch" type="button" id="authSwitch">${authMode==='register'?w.switchLogin:w.switchRegister}</button><p class="auth-notice">${w.notice}</p><p class="auth-secure">${w.secure}</p><div class="auth-bottom"><button type="button" id="authLanguage" class="auth-lang">${locale==='ar'?'English':'العربية'}</button><span>مِداد · 2026</span></div></div>`;
  $('#authSwitch',root).addEventListener('click',()=>{authMode=authMode==='register'?'login':'register';renderGate('',{preserveFields:false});});
  $('#authLanguage',root).addEventListener('click',()=>setLocale(locale==='ar'?'en':'ar'));
  const form=$('#midadAuthForm',root);
  form.addEventListener('submit',submitAuth);
  for(const [name,value] of Object.entries(savedValues)){const field=form.elements.namedItem(name);if(field)field.value=value;}
  if(focusedName){const field=form.elements.namedItem(focusedName);if(field)field.focus({preventScroll:true});}
}
function setGateMessage(message,isError=false){const el=$('#authMessage');if(el){el.textContent=message;el.classList.toggle('error',isError);}}
function parseLegacyState(){try{const value=JSON.parse(localStorage.getItem(STORAGE_KEY)||'null');if(value&&typeof value==='object'&&!Array.isArray(value))return {...DEFAULT_STATE,...value};}catch{}return structuredClone(DEFAULT_STATE);}
function installSyncAdapter(){
  if(syncAdapterInstalled)return;
  syncAdapterInstalled=true;
  const original=Storage.prototype.setItem;
  Storage.prototype.setItem=function(key,value){original.call(this,key,value);if(key!==STORAGE_KEY||!auth)return;pendingState=String(value);clearTimeout(syncTimer);syncTimer=setTimeout(()=>flushPendingState(),300);};
  window.addEventListener('pagehide',()=>{if(!pendingState||!auth)return;const snapshot=pendingState;const headers={'Content-Type':'application/json','X-CSRF-Token':auth.csrf};fetch('/api/learning/state',{method:'PUT',headers,body:snapshot,credentials:'same-origin',keepalive:true}).catch(()=>{});});
}
function flushPendingState(){
  clearTimeout(syncTimer);syncTimer=0;
  if(pendingState){const snapshot=pendingState;pendingState='';syncQueue=syncQueue.catch(()=>{}).then(()=>api('/api/learning/state',{method:'PUT',body:snapshot})).catch(error=>{window.dispatchEvent(new CustomEvent('midad:sync-error'));throw error;});}
  return syncQueue;
}
function renderProfile(){
  const button=$('#profileButton');if(!button||!auth)return;
  const avatar=$('.avatar',button);if(avatar)avatar.textContent=(auth.user.displayName||auth.user.username||auth.user.email||'م').trim().slice(0,1);
  const meta=$('.profile-meta',button);if(meta)meta.innerHTML=`<b>${escapeHtml(auth.user.displayName||auth.user.username||auth.user.email)}</b><small>${auth.user.username?`@${escapeHtml(auth.user.username)} · `:''}${escapeHtml(auth.user.email)} · ${locale==='ar'?'حساب طالب':'Student account'}</small>`;
  button.title=auth.user.email;
}
function escapeHtml(value){return String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
async function completeLogin(result,{created=false,legacy=null}={}){
  auth={user:result.user,csrf:result.csrfToken};window.MIDAD_AUTH={get user(){return auth?.user||null;},get csrf(){return auth?.csrf||'';},api,logout,flush:flushPendingState,setLocale(next){setLocale(next);renderProfile();}};
  let state;
  if(created){state=legacy||structuredClone(DEFAULT_STATE);await api('/api/learning/state',{method:'PUT',body:JSON.stringify(state)});}
  else {const remote=await api('/api/learning/state');state=remote.state||structuredClone(DEFAULT_STATE);}
  localStorage.setItem(STORAGE_KEY,JSON.stringify(state));
  installSyncAdapter();
  const nextLocale=state.preferences?.lang==='en'?'en':'ar';setLocale(nextLocale);
  const h=await api('/api/health').catch(()=>({aiConfigured:false}));window.MIDAD_HEALTH=h;
  mountChrome();renderProfile();document.body.dataset.authenticated='true';document.body.dataset.authReady='true';
  $('#authGate')?.remove();
  await import('./app.js?v=netlify-core-20261007');
  if(created)window.dispatchEvent(new CustomEvent('midad:notice',{detail:copy().created}));
}
async function submitAuth(event){
  event.preventDefault();const form=event.currentTarget;const submit=$('.auth-submit',form);if(submit)submit.disabled=true;
  setGateMessage(copy().loading,false);
  const formData=new FormData(form);const email=String(formData.get('email')||'').trim();const identifier=String(formData.get('identifier')||'').trim();const username=String(formData.get('username')||'').trim();const password=String(formData.get('password')||'');const displayName=String(formData.get('displayName')||'').trim();
  if(authMode==='register'&&!email){setGateMessage(copy().emailRequired,true);if(submit)submit.disabled=false;return;}
  if(authMode==='login'&&!identifier){setGateMessage(copy().identifier,true);if(submit)submit.disabled=false;return;}
  if(authMode==='register'&&!displayName){setGateMessage(copy().nameRequired,true);if(submit)submit.disabled=false;return;}
  if(authMode==='register'&&!username){setGateMessage(copy().usernameRequired,true);if(submit)submit.disabled=false;return;}
  if(authMode==='register'&&!/^[A-Za-z0-9][A-Za-z0-9_.-]{2,31}$/.test(username)){setGateMessage(copy().usernamePolicy,true);if(submit)submit.disabled=false;return;}
  if(authMode==='register'&&(password.length<12||password.length>128)){setGateMessage(copy().passwordPolicy,true);if(submit)submit.disabled=false;return;}
  const legacy=authMode==='register'?parseLegacyState():null;
  try{
    const body=authMode==='register'?{email,username,password,displayName}:{identifier,password};
    const result=await api(authMode==='register'?'/api/auth/register':'/api/auth/login',{method:'POST',body});
    await completeLogin(result,{created:authMode==='register',legacy});
  }catch(err){
    let message=authMode==='register'?copy().registerError:copy().loginError;
    if(err.code==='account_exists')message=copy().accountExists;
    else if(err.code==='username_taken')message=copy().usernameTaken;
    else if(err.code==='invalid_username')message=copy().usernamePolicy;
    else if(err.code==='password_policy')message=copy().passwordPolicy;
    else if(err.code==='invalid_email')message=copy().emailRequired;
    else if(err.status===0||err.name==='TypeError')message=copy().sessionError;
    setGateMessage(message,true);if(submit)submit.disabled=false;
  }
}
async function logout(){
  if(!auth)return;
  try{await api('/api/auth/logout',{method:'POST'});}catch{}
  auth=null;window.MIDAD_AUTH=null;localStorage.removeItem(STORAGE_KEY);document.body.dataset.authenticated='false';document.body.dataset.authReady='true';location.reload();
}
async function begin(){
  document.body.dataset.authReady='false';document.body.dataset.authenticated='false';
  mountChrome();renderGate(copy().loading);
  try{
    const session=await api('/api/auth/session');
    if(session.authenticated){await completeLogin(session);return;}
    document.body.dataset.authReady='true';setGateMessage('');
  }catch{document.body.dataset.authReady='true';setGateMessage(copy().sessionError,true);}
  window.addEventListener('online',()=>{if(!auth)api('/api/auth/session').then(s=>{if(s.authenticated)completeLogin(s).catch(()=>{});}).catch(()=>{});});
}

// The profile control is a true session action, not a decorative preview menu.
document.addEventListener('click',event=>{
  const button=event.target.closest('#profileButton');if(!button||!auth)return;
  event.preventDefault();event.stopImmediatePropagation();if(window.confirm(copy().logout))logout();
},true);
const langObserver=new MutationObserver(()=>{updateAnnouncement();const f=$('.app-footer');if(f&&auth){mountChrome();renderProfile();}});
langObserver.observe(document.documentElement,{attributes:true,attributeFilter:['lang']});
begin();
