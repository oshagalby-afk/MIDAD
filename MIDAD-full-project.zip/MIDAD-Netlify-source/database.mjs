import { DatabaseSync } from 'node:sqlite';
import fs from 'node:fs';
import path from 'node:path';

export const DEFAULT_LEARNING_STATE = {
  schema: 1,
  preferences: { lang: 'ar', theme: 'light' },
  subjects: [], lectures: [], notes: [], cards: [], questions: [], tasks: [],
  sessions: [], quizAttempts: [], reviewHistory: [], folders: [],
  activeQuiz: null, timer: null, aiConversations: [],
};

const SCHEMA = `
PRAGMA foreign_keys = ON;
PRAGMA busy_timeout = 5000;
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY, email TEXT NOT NULL UNIQUE COLLATE NOCASE,
  password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'student'
    CHECK(role IN ('student','teacher','admin')),
  email_verified INTEGER NOT NULL DEFAULT 0 CHECK(email_verified IN (0,1)),
  disabled INTEGER NOT NULL DEFAULT 0 CHECK(disabled IN (0,1)),
  created_at TEXT NOT NULL, last_login_at TEXT
);
CREATE TABLE IF NOT EXISTS profiles (
  user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  username TEXT, display_name TEXT NOT NULL DEFAULT '', locale TEXT NOT NULL DEFAULT 'ar',
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS sessions (
  token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  csrf_hash TEXT NOT NULL, expires_at TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS sessions_user_expiry ON sessions(user_id, expires_at);
CREATE TABLE IF NOT EXISTS learning_state (
  user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  state_json TEXT NOT NULL, revision INTEGER NOT NULL DEFAULT 1, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS subjects (
  owner_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  id TEXT NOT NULL, name TEXT NOT NULL, description TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL, data_json TEXT NOT NULL,
  PRIMARY KEY(owner_id,id)
);
CREATE TABLE IF NOT EXISTS courses (
  owner_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  id TEXT NOT NULL, subject_id TEXT, title TEXT NOT NULL DEFAULT '', data_json TEXT NOT NULL,
  PRIMARY KEY(owner_id,id)
);
CREATE TABLE IF NOT EXISTS lectures (
  owner_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  id TEXT NOT NULL, subject_id TEXT, title TEXT NOT NULL, done INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL, data_json TEXT NOT NULL,
  PRIMARY KEY(owner_id,id),
  FOREIGN KEY(owner_id,subject_id) REFERENCES subjects(owner_id,id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS files (
  owner_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  id TEXT NOT NULL, filename TEXT NOT NULL, media_type TEXT NOT NULL,
  size_bytes INTEGER NOT NULL CHECK(size_bytes > 0), status TEXT NOT NULL
    CHECK(status IN ('uploading','processing','ready','failed')),
  storage_key TEXT NOT NULL, preview_kind TEXT NOT NULL DEFAULT 'download',
  favorite INTEGER NOT NULL DEFAULT 0 CHECK(favorite IN (0,1)), folder_id TEXT, subject_id TEXT,
  extracted_chars INTEGER NOT NULL DEFAULT 0, processing_error TEXT,
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
  PRIMARY KEY(owner_id,id), UNIQUE(owner_id,storage_key)
);
CREATE INDEX IF NOT EXISTS files_owner_status ON files(owner_id,status,created_at DESC);
CREATE TABLE IF NOT EXISTS file_chunks (
  owner_id TEXT NOT NULL, file_id TEXT NOT NULL, chunk_no INTEGER NOT NULL,
  page_no INTEGER, section TEXT, content TEXT NOT NULL,
  PRIMARY KEY(owner_id,file_id,chunk_no),
  FOREIGN KEY(owner_id,file_id) REFERENCES files(owner_id,id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS file_chunks_lookup ON file_chunks(owner_id,file_id,page_no);
CREATE TABLE IF NOT EXISTS documents (
  owner_id TEXT NOT NULL, file_id TEXT NOT NULL, extracted_text TEXT NOT NULL DEFAULT '',
  language TEXT, processed_at TEXT,
  PRIMARY KEY(owner_id,file_id),
  FOREIGN KEY(owner_id,file_id) REFERENCES files(owner_id,id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS notes (
  owner_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  id TEXT NOT NULL, subject_id TEXT, title TEXT NOT NULL DEFAULT '', body TEXT NOT NULL DEFAULT '',
  favorite INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
  data_json TEXT NOT NULL, PRIMARY KEY(owner_id,id),
  FOREIGN KEY(owner_id,subject_id) REFERENCES subjects(owner_id,id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS flashcards (
  owner_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  id TEXT NOT NULL, subject_id TEXT, front TEXT NOT NULL, back TEXT NOT NULL,
  due_at TEXT, interval_days INTEGER NOT NULL DEFAULT 0, repetitions INTEGER NOT NULL DEFAULT 0,
  ease REAL NOT NULL DEFAULT 2.5, last_reviewed_at TEXT, data_json TEXT NOT NULL,
  PRIMARY KEY(owner_id,id),
  FOREIGN KEY(owner_id,subject_id) REFERENCES subjects(owner_id,id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS quizzes (
  owner_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  id TEXT NOT NULL, subject_id TEXT, title TEXT NOT NULL DEFAULT '', data_json TEXT NOT NULL,
  created_at TEXT NOT NULL, PRIMARY KEY(owner_id,id)
);
CREATE TABLE IF NOT EXISTS questions (
  owner_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  id TEXT NOT NULL, subject_id TEXT, prompt TEXT NOT NULL, answer TEXT NOT NULL,
  question_type TEXT NOT NULL DEFAULT 'short', options_json TEXT NOT NULL DEFAULT '[]',
  topic TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL, data_json TEXT NOT NULL,
  PRIMARY KEY(owner_id,id),
  FOREIGN KEY(owner_id,subject_id) REFERENCES subjects(owner_id,id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS quiz_attempts (
  owner_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  id TEXT NOT NULL, subject_id TEXT, total INTEGER NOT NULL, correct INTEGER NOT NULL,
  missed_topics_json TEXT NOT NULL DEFAULT '[]', ended_at TEXT NOT NULL, data_json TEXT NOT NULL,
  PRIMARY KEY(owner_id,id)
);
CREATE TABLE IF NOT EXISTS study_sessions (
  owner_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  id TEXT NOT NULL, subject_id TEXT, minutes INTEGER NOT NULL, started_at TEXT,
  ended_at TEXT NOT NULL, data_json TEXT NOT NULL, PRIMARY KEY(owner_id,id)
);
CREATE TABLE IF NOT EXISTS study_plans (
  owner_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  id TEXT NOT NULL, title TEXT NOT NULL, starts_at TEXT, ends_at TEXT, data_json TEXT NOT NULL,
  PRIMARY KEY(owner_id,id)
);
CREATE TABLE IF NOT EXISTS tasks (
  owner_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  id TEXT NOT NULL, subject_id TEXT, title TEXT NOT NULL, due_date TEXT,
  priority TEXT NOT NULL DEFAULT 'low', done INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL, data_json TEXT NOT NULL, PRIMARY KEY(owner_id,id)
);
CREATE INDEX IF NOT EXISTS tasks_owner_due ON tasks(owner_id,due_date,done);
CREATE TABLE IF NOT EXISTS bookmarks (
  owner_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  id TEXT NOT NULL, resource_type TEXT NOT NULL, resource_id TEXT NOT NULL,
  created_at TEXT NOT NULL, PRIMARY KEY(owner_id,id)
);
CREATE TABLE IF NOT EXISTS search_history (
  owner_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  id TEXT NOT NULL, query_hash TEXT NOT NULL, created_at TEXT NOT NULL, PRIMARY KEY(owner_id,id)
);
CREATE TABLE IF NOT EXISTS ai_conversations (
  owner_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  id TEXT NOT NULL, title TEXT NOT NULL DEFAULT '', context_file_id TEXT,
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL, PRIMARY KEY(owner_id,id)
);
CREATE TABLE IF NOT EXISTS ai_messages (
  owner_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  id TEXT NOT NULL, conversation_id TEXT NOT NULL, role TEXT NOT NULL CHECK(role IN ('user','assistant')),
  content TEXT NOT NULL, evidence_level TEXT, created_at TEXT NOT NULL,
  PRIMARY KEY(owner_id,id),
  FOREIGN KEY(owner_id,conversation_id) REFERENCES ai_conversations(owner_id,id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS ai_sources (
  owner_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  message_id TEXT NOT NULL, source_key TEXT NOT NULL, source_type TEXT NOT NULL,
  title TEXT NOT NULL, url TEXT NOT NULL, doi TEXT, pmid TEXT, page_no INTEGER,
  metadata_json TEXT NOT NULL DEFAULT '{}',
  PRIMARY KEY(owner_id,message_id,source_key),
  FOREIGN KEY(owner_id,message_id) REFERENCES ai_messages(owner_id,id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS ai_usage (
  id TEXT PRIMARY KEY, owner_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  provider TEXT NOT NULL, model TEXT NOT NULL, input_tokens INTEGER NOT NULL DEFAULT 0,
  output_tokens INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ai_usage_owner_date ON ai_usage(owner_id,created_at);
CREATE TABLE IF NOT EXISTS notifications (
  owner_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  id TEXT NOT NULL, kind TEXT NOT NULL, payload_json TEXT NOT NULL DEFAULT '{}',
  read_at TEXT, created_at TEXT NOT NULL, PRIMARY KEY(owner_id,id)
);
CREATE TABLE IF NOT EXISTS analytics (
  owner_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  id TEXT NOT NULL, event_type TEXT NOT NULL, value_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL, PRIMARY KEY(owner_id,id)
);
CREATE TABLE IF NOT EXISTS audit_logs (
  id TEXT PRIMARY KEY, actor_id TEXT REFERENCES users(id) ON DELETE SET NULL,
  action TEXT NOT NULL, resource_type TEXT, resource_id TEXT, outcome TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS audit_owner_date ON audit_logs(actor_id,created_at);
`;

export function normalizeLearningState(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw new Error('invalid_state');
  const state = { ...structuredClone(DEFAULT_LEARNING_STATE), ...input };
  state.preferences = {
    lang: input.preferences?.lang === 'en' ? 'en' : 'ar',
    theme: input.preferences?.theme === 'dark' ? 'dark' : 'light',
  };
  const safeId = value => typeof value === 'string' && /^[a-zA-Z0-9-]{1,80}$/.test(value);
  const keys = Object.keys(DEFAULT_LEARNING_STATE).filter(k => Array.isArray(DEFAULT_LEARNING_STATE[k]));
  for (const key of keys) {
    const arr = Array.isArray(input[key]) ? input[key] : [];
    if (arr.length > 5000) throw new Error('too_many_records');
    state[key] = arr.filter(x => x && typeof x === 'object' && !Array.isArray(x) && safeId(x.id)).map(x => JSON.parse(JSON.stringify(x)));
  }
  const subjectIds = new Set(state.subjects.map(x => x.id));
  for (const key of ['lectures','notes','cards','questions','tasks']) {
    state[key] = state[key].filter(x => !x.subjectId || subjectIds.has(x.subjectId));
  }
  state.schema = 1;
  return state;
}

export function openDatabase(dataDir) {
  fs.mkdirSync(dataDir, { recursive: true, mode: 0o700 });
  try { fs.chmodSync(dataDir, 0o700); } catch {}
  const dbPath = path.join(dataDir, 'midad.sqlite');
  const db = new DatabaseSync(dbPath);
  try { fs.chmodSync(dbPath, 0o600); } catch {}
  db.exec('PRAGMA journal_mode = WAL; PRAGMA synchronous = FULL;');
  db.exec(SCHEMA);
  const userColumns = db.prepare('PRAGMA table_info(users)').all().map(column => column.name);
  if (!userColumns.includes('email_verified')) db.exec('ALTER TABLE users ADD COLUMN email_verified INTEGER NOT NULL DEFAULT 0 CHECK(email_verified IN (0,1))');
  const profileColumns = db.prepare('PRAGMA table_info(profiles)').all().map(column => column.name);
  if (!profileColumns.includes('username')) db.exec('ALTER TABLE profiles ADD COLUMN username TEXT');
  db.exec('CREATE UNIQUE INDEX IF NOT EXISTS profiles_username_nocase ON profiles(username COLLATE NOCASE) WHERE username IS NOT NULL');
  const fileColumns = db.prepare('PRAGMA table_info(files)').all().map(column => column.name);
  if (!fileColumns.includes('favorite')) db.exec('ALTER TABLE files ADD COLUMN favorite INTEGER NOT NULL DEFAULT 0 CHECK(favorite IN (0,1))');
  if (!fileColumns.includes('folder_id')) db.exec('ALTER TABLE files ADD COLUMN folder_id TEXT');
  if (!fileColumns.includes('subject_id')) db.exec('ALTER TABLE files ADD COLUMN subject_id TEXT');
  return db;
}

export function readLearningState(db, userId) {
  const row = db.prepare('SELECT state_json, revision, updated_at FROM learning_state WHERE user_id=?').get(userId);
  return row ? { state: JSON.parse(row.state_json), revision: row.revision, updatedAt: row.updated_at } : null;
}

export function writeLearningState(db, userId, input) {
  const state = normalizeLearningState(input);
  const now = new Date().toISOString();
  const json = JSON.stringify(state);
  if (Buffer.byteLength(json) > 5 * 1024 * 1024) throw new Error('state_too_large');
  db.exec('BEGIN IMMEDIATE');
  try {
    db.prepare(`INSERT INTO learning_state(user_id,state_json,revision,updated_at) VALUES(?,?,1,?)
      ON CONFLICT(user_id) DO UPDATE SET state_json=excluded.state_json,revision=learning_state.revision+1,updated_at=excluded.updated_at`).run(userId,json,now);
    const tables = ['lectures','notes','flashcards','questions','quiz_attempts','study_sessions','tasks','subjects'];
    for (const table of tables) db.prepare(`DELETE FROM ${table} WHERE owner_id=?`).run(userId);
    const subject = db.prepare('INSERT INTO subjects(owner_id,id,name,description,created_at,data_json) VALUES(?,?,?,?,?,?)');
    for (const x of state.subjects) subject.run(userId,x.id,String(x.name||'').slice(0,240),String(x.description||'').slice(0,3000),String(x.createdAt||now),JSON.stringify(x));
    const lecture = db.prepare('INSERT INTO lectures(owner_id,id,subject_id,title,done,created_at,data_json) VALUES(?,?,?,?,?,?,?)');
    for (const x of state.lectures) lecture.run(userId,x.id,x.subjectId||null,String(x.title||'').slice(0,500),x.done?1:0,String(x.createdAt||now),JSON.stringify(x));
    const note = db.prepare('INSERT INTO notes(owner_id,id,subject_id,title,body,favorite,created_at,updated_at,data_json) VALUES(?,?,?,?,?,?,?,?,?)');
    for (const x of state.notes) note.run(userId,x.id,x.subjectId||null,String(x.title||'').slice(0,500),String(x.body||'').slice(0,300000),x.favorite?1:0,String(x.createdAt||now),String(x.updatedAt||now),JSON.stringify(x));
    const card = db.prepare('INSERT INTO flashcards(owner_id,id,subject_id,front,back,due_at,interval_days,repetitions,ease,last_reviewed_at,data_json) VALUES(?,?,?,?,?,?,?,?,?,?,?)');
    for (const x of state.cards) card.run(userId,x.id,x.subjectId||null,String(x.front||'').slice(0,5000),String(x.back||'').slice(0,10000),x.dueAt||null,Math.max(0,Number(x.intervalDays)||0),Math.max(0,Number(x.repetitions)||0),Number(x.ease)||2.5,x.lastReviewedAt||null,JSON.stringify(x));
    const question = db.prepare('INSERT INTO questions(owner_id,id,subject_id,prompt,answer,question_type,options_json,topic,created_at,data_json) VALUES(?,?,?,?,?,?,?,?,?,?)');
    for (const x of state.questions) question.run(userId,x.id,x.subjectId||null,String(x.prompt||'').slice(0,5000),String(x.answer||'').slice(0,5000),['mcq','tf','short'].includes(x.type)?x.type:'short',JSON.stringify(Array.isArray(x.options)?x.options.slice(0,30):[]),String(x.topic||'').slice(0,500),String(x.createdAt||now),JSON.stringify(x));
    const attempt = db.prepare('INSERT INTO quiz_attempts(owner_id,id,subject_id,total,correct,missed_topics_json,ended_at,data_json) VALUES(?,?,?,?,?,?,?,?)');
    for (const x of state.quizAttempts) attempt.run(userId,x.id,x.subjectId||null,Math.max(0,Number(x.total)||0),Math.max(0,Number(x.correct)||0),JSON.stringify(Array.isArray(x.missedTopics)?x.missedTopics:[]),String(x.endedAt||now),JSON.stringify(x));
    const session = db.prepare('INSERT INTO study_sessions(owner_id,id,subject_id,minutes,started_at,ended_at,data_json) VALUES(?,?,?,?,?,?,?)');
    for (const x of state.sessions) session.run(userId,x.id,x.subjectId||null,Math.max(0,Number(x.minutes)||0),x.startedAt||null,String(x.endedAt||now),JSON.stringify(x));
    const task = db.prepare('INSERT INTO tasks(owner_id,id,subject_id,title,due_date,priority,done,created_at,data_json) VALUES(?,?,?,?,?,?,?,?,?)');
    for (const x of state.tasks) task.run(userId,x.id,x.subjectId||null,String(x.title||'').slice(0,500),x.dueDate||null,['low','medium','high'].includes(x.priority)?x.priority:'low',x.done?1:0,String(x.createdAt||now),JSON.stringify(x));
    db.exec('COMMIT');
  } catch (error) {
    db.exec('ROLLBACK');
    throw error;
  }
  return readLearningState(db,userId);
}
