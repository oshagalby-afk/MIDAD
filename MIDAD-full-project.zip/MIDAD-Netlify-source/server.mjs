import http from 'node:http';
import path from 'node:path';
import fs from 'node:fs';
import { readFile, realpath, writeFile, mkdir, unlink } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { randomBytes, randomUUID, createHash, scrypt as scryptCb, timingSafeEqual } from 'node:crypto';
import { promisify } from 'node:util';
import { File } from 'node:buffer';
import { openDatabase, DEFAULT_LEARNING_STATE, readLearningState, writeLearningState } from './database.mjs';
import { validateLocalFile, sanitizeLocalFileName } from './file-policy.mjs';
import { extractDocument, makeChunks } from './file-processing.mjs';
import { answerMidadAI } from './ai-service.mjs';

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const scrypt = promisify(scryptCb);
const SESSION_TTL_MS = 14 * 24 * 60 * 60 * 1000;
const MAX_UPLOAD = 50 * 1024 * 1024;
const STATIC_FILES = new Map([
  ['/', 'index.html'], ['/index.html', 'index.html'], ['/styles.css', 'styles.css'],
  ['/app.js', 'app.js'], ['/file-policy.mjs', 'file-policy.mjs'], ['/icon.svg', 'icon.svg'],
  ['/bootstrap.mjs', 'bootstrap.mjs'],
  ['/manifest.webmanifest', 'manifest.webmanifest'], ['/sw.js', 'sw.js'],
]);
const CONTENT_TYPES = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8',
  '.svg': 'image/svg+xml', '.webmanifest': 'application/manifest+json; charset=utf-8',
};
const MIME_BY_EXT = {
  pdf: 'application/pdf', txt: 'text/plain', md: 'text/markdown',
  doc: 'application/msword', docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  ppt: 'application/vnd.ms-powerpoint', pptx: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', webp: 'image/webp',
  mp3: 'audio/mpeg', wav: 'audio/wav', mp4: 'video/mp4', mov: 'video/quicktime',
};

function securityHeaders(req) {
  const headers = {
    'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; media-src 'self' blob:; frame-src blob:; worker-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'",
    'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'DENY',
    'Referrer-Policy': 'strict-origin-when-cross-origin',
    'Permissions-Policy': 'camera=(), microphone=(), geolocation=(), payment=()',
    'Cross-Origin-Opener-Policy': 'same-origin', 'Cross-Origin-Resource-Policy': 'same-origin',
    'Cache-Control': 'no-store',
  };
  if (publicProtocol(req)==='https') headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains';
  return headers;
}

function json(res, status, body, extra = {}) {
  const text = JSON.stringify(body);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Length': Buffer.byteLength(text), ...extra });
  res.end(text);
}
function error(res, status, code, message = 'تعذّر تنفيذ الطلب.') { json(res,status,{error:code,message}); }
function safeRequestPath(rawUrl) {
  try {
    let value = new URL(rawUrl,'http://localhost').pathname;
    for (let i=0;i<2;i++) value=decodeURIComponent(value);
    if (value.includes('\\') || value.includes('\0') || value.split('/').some(p=>p==='.'||p==='..')) return null;
    return value;
  } catch { return null; }
}
async function readBody(req, limit) {
  const parts=[]; let size=0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > limit) { const e=new Error('body_too_large'); e.status=413; throw e; }
    parts.push(chunk);
  }
  return Buffer.concat(parts,size);
}
async function readJson(req, limit = 128 * 1024) {
  const buf = await readBody(req,limit);
  try { const v=JSON.parse(buf.toString('utf8')); if (!v || typeof v!=='object' || Array.isArray(v)) throw new Error(); return v; }
  catch { const e=new Error('invalid_json'); e.status=400; throw e; }
}
function hash(value) { return createHash('sha256').update(value).digest('hex'); }
function csrfForSession(token) { return createHash('sha256').update(`midad-csrf:${token}`).digest('base64url'); }
function secureEqual(a,b) {
  const x=Buffer.from(String(a||'')),y=Buffer.from(String(b||''));
  return x.length===y.length && timingSafeEqual(x,y);
}
function cookies(req) {
  const out={};
  for (const part of String(req.headers.cookie||'').split(';')) {
    const i=part.indexOf('='); if (i<0) continue;
    const key=part.slice(0,i).trim(); const value=part.slice(i+1).trim();
    if (key && value) out[key]=value;
  }
  return out;
}
function publicHost(req) {
  const forwarded=process.env.MIDAD_TRUST_PROXY==='true'?req.headers['x-forwarded-host']:'';
  return String(forwarded||req.headers.host||'').split(',')[0].trim();
}
function publicProtocol(req) {
  const forwarded=process.env.MIDAD_TRUST_PROXY==='true'?String(req.headers['x-forwarded-proto']||'').split(',')[0].trim().toLowerCase():'';
  return req.socket.encrypted||forwarded==='https'?'https':'http';
}
function checkOrigin(req) {
  const origin=req.headers.origin;
  if (!origin) return true;
  try {
    const parsed=new URL(origin);
    return ['http:','https:'].includes(parsed.protocol)&&parsed.origin.toLowerCase()===`${publicProtocol(req)}://${publicHost(req)}`.toLowerCase();
  }
  catch { return false; }
}
function rateLimit(store,key,maximum,windowMs) {
  const now=Date.now(); const data=store.get(key);
  if (!data || now-data.start>=windowMs) { store.set(key,{start:now,count:1}); return true; }
  data.count++; return data.count<=maximum;
}
function requestIp(req) { return req.socket.remoteAddress || 'unknown'; }
function setSessionCookie(req,res,token) {
  const secure=publicProtocol(req)==='https';
  res.setHeader('Set-Cookie',`midad.sid=${token}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${Math.floor(SESSION_TTL_MS/1000)}${secure?'; Secure':''}`);
}
function clearSessionCookie(req,res) {
  const secure=publicProtocol(req)==='https';
  res.setHeader('Set-Cookie',`midad.sid=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0${secure?'; Secure':''}`);
}
function audit(db,userId,action,type=null,id=null,outcome='success') {
  db.prepare('INSERT INTO audit_logs(id,actor_id,action,resource_type,resource_id,outcome,created_at) VALUES(?,?,?,?,?,?,?)').run(randomUUID(),userId||null,action,type,id,outcome,new Date().toISOString());
}
async function passwordHash(password) {
  const salt=randomBytes(16);
  const derived=await scrypt(password,salt,64,{N:16384,r:8,p:1,maxmem:64*1024*1024});
  return `scrypt$16384$8$1$${salt.toString('base64url')}$${Buffer.from(derived).toString('base64url')}`;
}
async function verifyPassword(password,stored) {
  try {
    const [scheme,n,r,p,saltText,hashText]=stored.split('$');
    if (scheme!=='scrypt'||Number(n)!==16384||Number(r)!==8||Number(p)!==1) return false;
    const salt=Buffer.from(saltText,'base64url'), expected=Buffer.from(hashText,'base64url');
    const actual=Buffer.from(await scrypt(password,salt,expected.length,{N:16384,r:8,p:1,maxmem:64*1024*1024}));
    return secureEqual(actual,expected);
  } catch { return false; }
}
function getAuth(db,req) {
  const token=cookies(req)['midad.sid'];
  if (!token || !/^[\w-]{40,60}$/.test(token)) return null;
  const row=db.prepare(`SELECT s.token_hash,s.user_id,s.csrf_hash,s.expires_at,u.email,u.role,u.disabled,p.username,p.display_name,p.locale
    FROM sessions s JOIN users u ON u.id=s.user_id LEFT JOIN profiles p ON p.user_id=u.id
    WHERE s.token_hash=?`).get(hash(token));
  if (!row || row.disabled || new Date(row.expires_at).getTime()<=Date.now()) {
    if (row) db.prepare('DELETE FROM sessions WHERE token_hash=?').run(row.token_hash);
    return null;
  }
  return { ...row, token };
}
function requireCsrf(req,auth) {
  if (!auth || !checkOrigin(req)) return false;
  return secureEqual(hash(String(req.headers['x-csrf-token']||'')),auth.csrf_hash);
}
function userPublic(auth) { return { id:auth.user_id,email:auth.email,username:auth.username||'',displayName:auth.display_name||'',role:auth.role,locale:auth.locale||'ar' }; }
function newSession(db,userId,req,res) {
  const token=randomBytes(32).toString('base64url');
  const csrf=csrfForSession(token);
  const now=new Date(); const expires=new Date(now.getTime()+SESSION_TTL_MS).toISOString();
  db.prepare('INSERT INTO sessions(token_hash,user_id,csrf_hash,expires_at,created_at) VALUES(?,?,?,?,?)').run(hash(token),userId,hash(csrf),expires,now.toISOString());
  setSessionCookie(req,res,token);
  return csrf;
}
function normalizeEmail(value) {
  const email=String(value||'').trim().normalize('NFKC').toLowerCase();
  if (email.length>254 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return null;
  return email;
}
function normalizeUsername(value) {
  const username=String(value||'').trim().normalize('NFKC');
  if (username.length<3 || username.length>32 || !/^[A-Za-z0-9][A-Za-z0-9_.-]{2,31}$/.test(username)) return null;
  return username;
}
function safeId(value) { return typeof value==='string' && /^[a-zA-Z0-9-]{1,80}$/.test(value); }
function safeFileRow(row) {
  return { id:row.id,name:row.filename,type:row.media_type,previewKind:row.preview_kind,size:row.size_bytes,addedAt:row.created_at,favorite:Boolean(row.favorite),folderId:row.folder_id||null,subjectId:row.subject_id||'',status:row.status,processingError:row.processing_error||null,extractedChars:row.extracted_chars };
}
function signatureOkay(ext,b) {
  if (['docx','pptx'].includes(ext)) return b.length>=4 && b[0]===0x50 && b[1]===0x4b;
  if (['doc','ppt'].includes(ext)) return b.length>=8 && Buffer.from(b.subarray(0,8)).equals(Buffer.from([0xd0,0xcf,0x11,0xe0,0xa1,0xb1,0x1a,0xe1]));
  if (ext==='wav') return b.length>12 && b.toString('ascii',0,4)==='RIFF' && b.toString('ascii',8,12)==='WAVE';
  if (ext==='mp3') return b.length>3 && (b.toString('ascii',0,3)==='ID3' || (b[0]===0xff && (b[1]&0xe0)===0xe0));
  if (ext==='mp4'||ext==='mov') return b.length>=12 && b.toString('ascii',4,8)==='ftyp';
  return true;
}
function mimeOkay(ext,mime) {
  if (!mime || mime==='application/octet-stream') return true;
  const expected=MIME_BY_EXT[ext];
  if (ext==='md') return ['text/markdown','text/plain'].includes(mime);
  if (ext==='wav') return ['audio/wav','audio/x-wav','audio/wave'].includes(mime);
  return mime===expected;
}
async function validateServerUpload(name,mime,buffer) {
  const ext=path.extname(name).slice(1).toLowerCase();
  if (!mimeOkay(ext,mime)) return { ok:false,reason:'mime_mismatch' };
  if (!signatureOkay(ext,buffer)) return { ok:false,reason:'signature' };
  if (ext==='txt'||ext==='md') { try { new TextDecoder('utf-8',{fatal:true}).decode(buffer); } catch { return {ok:false,reason:'invalid_text'}; } }
  const file=new File([buffer],name,{type:mime||MIME_BY_EXT[ext]||'application/octet-stream'});
  const policy=await validateLocalFile(file,Infinity);
  if (!policy.ok) return policy;
  return { ...policy,ext,mime:mime||MIME_BY_EXT[ext]||'application/octet-stream' };
}
function privateFilePath(dataDir,userId,fileId) { return path.join(dataDir,'private',userId,`${fileId}.bin`); }

async function handleFileUpload(db,req,res,url,auth,dataDir,rateLimits) {
  if(!rateLimit(rateLimits,`upload:${auth.user_id}`,8,60*60*1000)||!rateLimit(rateLimits,`upload-ip:${requestIp(req)}`,12,60*60*1000))return error(res,429,'upload_rate_limited','وصلت إلى حد الرفع المؤقت؛ حاول لاحقًا.');
  const name=sanitizeLocalFileName(url.searchParams.get('name')||'');
  if (!name || name==='file') return error(res,400,'invalid_filename','اسم الملف غير صالح.');
  const subjectId=safeId(url.searchParams.get('subjectId')||'')?url.searchParams.get('subjectId'):'';
  const folderId=safeId(url.searchParams.get('folderId')||'')?url.searchParams.get('folderId'):'';
  if(subjectId&&!db.prepare('SELECT id FROM subjects WHERE owner_id=? AND id=?').get(auth.user_id,subjectId))return error(res,400,'invalid_subject','المادة المحددة غير موجودة.');
  if(folderId){const state=db.prepare('SELECT state_json FROM learning_state WHERE user_id=?').get(auth.user_id);let folders=[];try{folders=JSON.parse(state?.state_json||'{}').folders||[]}catch{}if(!folders.some(folder=>folder.id===folderId))return error(res,400,'invalid_folder','المجلد المحدد غير موجود.');}
  const mime=String(req.headers['x-midad-mime']||req.headers['content-type']||'application/octet-stream').split(';')[0].trim().toLowerCase();
  const buffer=await readBody(req,MAX_UPLOAD);
  const checked=await validateServerUpload(name,mime,buffer);
  if (!checked.ok) return error(res,400,checked.reason||'invalid_file','لم يُقبل الملف: فشل التحقق من النوع أو المحتوى.');
  const id=randomUUID(); const now=new Date().toISOString(); const storageKey=`${id}.bin`;
  const target=privateFilePath(dataDir,auth.user_id,id);
  await mkdir(path.dirname(target),{recursive:true,mode:0o700});
  const previewKind=checked.previewKind||'download';
  db.exec('BEGIN IMMEDIATE');
  try {
    const used=db.prepare('SELECT COALESCE(SUM(size_bytes),0) total FROM files WHERE owner_id=?').get(auth.user_id).total;
    if(used+buffer.length>300*1024*1024)throw new Error('storage_quota');
    const allUsed=db.prepare('SELECT COALESCE(SUM(size_bytes),0) total FROM files').get().total;
    if(allUsed+buffer.length>1024*1024*1024)throw new Error('server_storage_full');
    db.prepare(`INSERT INTO files(owner_id,id,filename,media_type,size_bytes,status,storage_key,preview_kind,folder_id,subject_id,created_at,updated_at)
      VALUES(?,?,?,?,?,'uploading',?,?,?,?,?,?)`).run(auth.user_id,id,name,checked.mime,buffer.length,storageKey,previewKind,folderId||null,subjectId||null,now,now);
    db.exec('COMMIT');
  } catch(e) {
    try { db.exec('ROLLBACK'); } catch {}
    if(e.message==='storage_quota')return error(res,413,'storage_quota','سيتجاوز هذا الملف حد التخزين المؤقت لهذا الحساب.');
    if(e.message==='server_storage_full')return error(res,503,'server_storage_full','مساحة رفع المعاينة ممتلئة مؤقتًا.');
    throw e;
  }
  try {
    await writeFile(target,buffer,{flag:'wx',mode:0o600});
    db.prepare("UPDATE files SET status='processing',updated_at=? WHERE owner_id=? AND id=?").run(new Date().toISOString(),auth.user_id,id);
  } catch(e) {
    await unlink(target).catch(()=>{});
    try { db.prepare('DELETE FROM files WHERE owner_id=? AND id=?').run(auth.user_id,id); } catch {}
    return error(res,500,'file_storage_failed','تعذر حفظ الملف بأمان؛ لم يُحتفظ بسجل رفع غير مكتمل.');
  }
  try {
    const extracted=extractDocument(name,target,buffer);
    const chunks=makeChunks(extracted.sections);
    db.exec('BEGIN IMMEDIATE');
    try {
      db.prepare('INSERT INTO documents(owner_id,file_id,extracted_text,language,processed_at) VALUES(?,?,?,?,?)').run(auth.user_id,id,extracted.text,'und',new Date().toISOString());
      const insert=db.prepare('INSERT INTO file_chunks(owner_id,file_id,chunk_no,page_no,section,content) VALUES(?,?,?,?,?,?)');
      chunks.forEach((c,i)=>insert.run(auth.user_id,id,i+1,c.page,c.section,c.content));
      db.prepare("UPDATE files SET status='ready',extracted_chars=?,processing_error=NULL,updated_at=? WHERE owner_id=? AND id=?").run(extracted.text.length,new Date().toISOString(),auth.user_id,id);
      db.exec('COMMIT');
    } catch (e) { db.exec('ROLLBACK'); throw e; }
  } catch (e) {
    const code=['legacy_office_not_extractable','format_not_text_extractable','no_extractable_text','processing_timeout','processing_unavailable','processing_failed','unsupported_office_content','office_content_too_large'].includes(e.message)?e.message:'processing_failed';
    db.prepare("UPDATE files SET status='failed',processing_error=?,updated_at=? WHERE owner_id=? AND id=?").run(code,new Date().toISOString(),auth.user_id,id);
  }
  const row=db.prepare('SELECT * FROM files WHERE owner_id=? AND id=?').get(auth.user_id,id);
  audit(db,auth.user_id,'file.upload','file',id,row.status);
  return json(res,201,{file:safeFileRow(row)});
}

async function serveStatic(req,res,pathName) {
  const relative=STATIC_FILES.get(pathName);
  if (!relative) return false;
  try {
    const target=path.join(ROOT,relative);
    const [rootReal,targetReal]=await Promise.all([realpath(ROOT),realpath(target)]);
    if (!targetReal.startsWith(rootReal+path.sep)||targetReal===rootReal) throw new Error('path');
    const body=await readFile(targetReal);
    res.writeHead(200,{'Content-Type':CONTENT_TYPES[path.extname(targetReal)]||'application/octet-stream','Content-Length':body.length});
    res.end(req.method==='HEAD'?undefined:body); return true;
  } catch { res.writeHead(404,{'Content-Type':'text/plain; charset=utf-8'});res.end(req.method==='HEAD'?undefined:'Not found');return true; }
}

export function createMidadServer({ dataDir = process.env.MIDAD_DATA_DIR || path.join(ROOT,'.midad-data') } = {}) {
  const db=openDatabase(dataDir);
  const rateLimits=new Map();
  const server=http.createServer(async (req,res)=>{
    for (const [key,value] of Object.entries(securityHeaders(req))) res.setHeader(key,value);
    if (req.method==='OPTIONS') { res.writeHead(405,{Allow:'GET, HEAD, POST, PUT, PATCH, DELETE'});res.end();return; }
    const pathname=safeRequestPath(req.url||'/');
    if (!pathname) return error(res,400,'invalid_path','مسار الطلب غير صالح.');
    if (pathname==='/api/health' && req.method==='GET') return json(res,200,{ok:true,backend:'sqlite',authentication:true,aiConfigured:Boolean(process.env.OPENAI_API_KEY&&(process.env.OPENAI_API_BASE||process.env.OPENAI_BASE_URL)),scientificSources:['PubMed','Europe PMC']});
    if (pathname.startsWith('/api/')) {
      try {
        const url=new URL(req.url||'/',`${publicProtocol(req)}://${publicHost(req)||'localhost'}`);
        const auth=getAuth(db,req);
        if (pathname==='/api/auth/register' && req.method==='POST') {
          if (!checkOrigin(req)) return error(res,403,'origin_rejected','الطلب ليس من نفس الموقع.');
          if (!rateLimit(rateLimits,`auth:${requestIp(req)}`,5,15*60*1000)) return error(res,429,'auth_rate_limited','محاولات كثيرة؛ حاول لاحقًا.');
          const body=await readJson(req,32*1024); const email=normalizeEmail(body.email); const username=normalizeUsername(body.username); const password=String(body.password||'');
          const displayName=String(body.displayName||'').normalize('NFKC').trim().replace(/[\u0000-\u001f\u007f]/g,'').slice(0,80);
          if (!email) return error(res,400,'invalid_email','أدخل بريدًا إلكترونيًا صالحًا.');
          if (!username) return error(res,400,'invalid_username','اسم المستخدم يجب أن يكون من 3 إلى 32 حرفًا أو رقمًا أو نقطة أو شرطة سفلية أو واصلة.');
          if (password.length<12 || password.length>128) return error(res,400,'password_policy','كلمة المرور يجب أن تكون بين 12 و128 حرفًا.');
          if (!displayName) return error(res,400,'display_name_required','أدخل الاسم الظاهر.');
          const id=randomUUID(),now=new Date().toISOString();
          // Public registration is never privileged: an unverified email cannot bootstrap an administrator.
          const role='student';
          const encodedPassword=await passwordHash(password);
          try {
            db.exec('BEGIN IMMEDIATE');
            db.prepare('INSERT INTO users(id,email,password_hash,role,created_at) VALUES(?,?,?,?,?)').run(id,email,encodedPassword,role,now);
            db.prepare('INSERT INTO profiles(user_id,username,display_name,locale,created_at,updated_at) VALUES(?,?,?,?,?,?)').run(id,username,displayName,'ar',now,now);
            db.exec('COMMIT');
          } catch (e) {
            try { db.exec('ROLLBACK'); } catch {}
            if (db.prepare('SELECT id FROM users WHERE email=?').get(email)) return error(res,409,'account_exists','يوجد حساب بهذا البريد بالفعل.');
            if (db.prepare('SELECT user_id FROM profiles WHERE username=? COLLATE NOCASE').get(username)) return error(res,409,'username_taken','اسم المستخدم مستخدم بالفعل. اختر اسمًا آخر.');
            throw e;
          }
          audit(db,id,'auth.register','user',id,'success');
          const csrfToken=newSession(db,id,req,res);
          const row={user_id:id,email,username,display_name:displayName,role,locale:'ar'};
          return json(res,201,{user:userPublic(row),csrfToken,emailVerified:false});
        }
        if (pathname==='/api/auth/login' && req.method==='POST') {
          if (!checkOrigin(req)) return error(res,403,'origin_rejected','الطلب ليس من نفس الموقع.');
          if (!rateLimit(rateLimits,`auth:${requestIp(req)}`,8,15*60*1000)) return error(res,429,'auth_rate_limited','محاولات كثيرة؛ حاول لاحقًا.');
          const body=await readJson(req,32*1024);const identifier=String(body.identifier||body.email||'').trim();const email=normalizeEmail(identifier);const username=normalizeUsername(identifier);const password=String(body.password||'');
          const row=(email||username)?db.prepare(`SELECT u.id,u.email,u.password_hash,u.role,u.disabled,p.username,p.display_name,p.locale FROM users u LEFT JOIN profiles p ON p.user_id=u.id WHERE u.email=? OR p.username=? COLLATE NOCASE`).get(email||'',username||''):null;
          if (!row||row.disabled||!await verifyPassword(password,row.password_hash)) { audit(db,null,'auth.login','user',null,'rejected');return error(res,401,'invalid_credentials','البريد أو اسم المستخدم أو كلمة المرور غير صحيحة.'); }
          db.prepare('UPDATE users SET last_login_at=? WHERE id=?').run(new Date().toISOString(),row.id);
          const csrfToken=newSession(db,row.id,req,res);audit(db,row.id,'auth.login','user',row.id,'success');
          const authRow={user_id:row.id,email:row.email,username:row.username,display_name:row.display_name,role:row.role,locale:row.locale};
          return json(res,200,{user:userPublic(authRow),csrfToken,emailVerified:false});
        }
        if (pathname==='/api/auth/session' && req.method==='GET') {
          if (!auth) return json(res,200,{authenticated:false});
          const csrfToken=csrfForSession(auth.token);
          if(auth.csrf_hash!==hash(csrfToken))db.prepare('UPDATE sessions SET csrf_hash=? WHERE token_hash=?').run(hash(csrfToken),auth.token_hash);
          return json(res,200,{authenticated:true,user:userPublic(auth),csrfToken,emailVerified:false});
        }
        if (pathname==='/api/auth/logout' && req.method==='POST') {
          if (auth&&!requireCsrf(req,auth)) return error(res,403,'csrf_rejected','انتهت صلاحية الجلسة؛ أعد تحميل الصفحة.');
          if (auth) { db.prepare('DELETE FROM sessions WHERE token_hash=?').run(auth.token_hash);audit(db,auth.user_id,'auth.logout','user',auth.user_id,'success'); }
          clearSessionCookie(req,res);return json(res,200,{ok:true});
        }
        if (!auth) return error(res,401,'authentication_required','سجّل الدخول للمتابعة.');
        if (['POST','PUT','PATCH','DELETE'].includes(req.method)&&!requireCsrf(req,auth)) return error(res,403,'csrf_rejected','انتهت صلاحية الجلسة؛ أعد تحميل الصفحة.');
        if (pathname==='/api/profile' && req.method==='PATCH') {
          const body=await readJson(req,16*1024);const displayName=String(body.displayName||'').trim().slice(0,80);const locale=body.locale==='en'?'en':'ar';
          if(!displayName)return error(res,400,'display_name_required','الاسم الظاهر مطلوب.');
          db.prepare('UPDATE profiles SET display_name=?,locale=?,updated_at=? WHERE user_id=?').run(displayName,locale,new Date().toISOString(),auth.user_id);return json(res,200,{ok:true});
        }
        if (pathname==='/api/learning/state' && req.method==='GET') return json(res,200,{...(readLearningState(db,auth.user_id)||{state:DEFAULT_LEARNING_STATE,revision:0,updatedAt:null})});
        if (pathname==='/api/learning/state' && req.method==='PUT') {
          const body=await readJson(req,5*1024*1024);
          try { const saved=writeLearningState(db,auth.user_id,body);return json(res,200,saved); }
          catch(e) { const status=e.message==='state_too_large'||e.message==='too_many_records'?413:400;return error(res,status,e.message||'invalid_state','تعذر حفظ بيانات التعلّم.'); }
        }
        if (pathname==='/api/files' && req.method==='GET') {
          const rows=db.prepare('SELECT * FROM files WHERE owner_id=? ORDER BY created_at DESC').all(auth.user_id);
          return json(res,200,{files:rows.map(safeFileRow)});
        }
        if(pathname==='/api/search'&&req.method==='GET') {
          if(!rateLimit(rateLimits,`search:${auth.user_id}`,90,60*1000))return error(res,429,'search_rate_limited','أجرِ عمليات بحث أقل قليلًا.');
          const query=String(url.searchParams.get('q')||'').trim().slice(0,160);if(query.length<2)return json(res,200,{results:[]});
          const terms=[...new Set(query.toLocaleLowerCase().split(/[^\p{L}\p{N}]+/u).filter(x=>x.length>1))].slice(0,8);
          if(!terms.length)return json(res,200,{results:[]});
          const where=terms.map(()=>'(instr(lower(c.content),lower(?))>0 OR instr(lower(f.filename),lower(?))>0)').join(' OR ');
          const params=terms.flatMap(term=>[term,term]);
          const results=db.prepare(`SELECT f.id,f.filename,f.status,c.page_no,c.section,substr(c.content,1,220) excerpt
            FROM file_chunks c JOIN files f ON f.owner_id=c.owner_id AND f.id=c.file_id
            WHERE c.owner_id=? AND f.status='ready' AND (${where}) ORDER BY f.created_at DESC,c.chunk_no LIMIT 12`).all(auth.user_id,...params);
          db.prepare('INSERT INTO search_history(owner_id,id,query_hash,created_at) VALUES(?,?,?,?)').run(auth.user_id,randomUUID(),hash(query.toLocaleLowerCase()),new Date().toISOString());
          return json(res,200,{results:results.map(row=>({id:row.id,name:row.filename,page:row.page_no,section:row.section,excerpt:row.excerpt}))});
        }
        if (pathname==='/api/files/upload' && req.method==='POST') return await handleFileUpload(db,req,res,url,auth,dataDir,rateLimits);
        const fileContent=pathname.match(/^\/api\/files\/([a-zA-Z0-9-]{1,80})\/content$/);
        const fileItem=pathname.match(/^\/api\/files\/([a-zA-Z0-9-]{1,80})$/);
        if (fileContent && (req.method==='GET'||req.method==='HEAD')) {
          const row=db.prepare('SELECT * FROM files WHERE owner_id=? AND id=?').get(auth.user_id,fileContent[1]);
          if(!row)return error(res,404,'file_not_found','الملف غير موجود.');
          const filePath=privateFilePath(dataDir,auth.user_id,row.id);const body=await readFile(filePath);
          const inline=['application/pdf','image/png','image/jpeg','image/webp'].includes(row.media_type);
          const safeName=encodeURIComponent(row.filename).replace(/[!'()*]/g,c=>`%${c.charCodeAt(0).toString(16).toUpperCase()}`);
          res.writeHead(200,{'Content-Type':row.media_type,'Content-Length':body.length,'Content-Disposition':`${inline?'inline':'attachment'}; filename*=UTF-8''${safeName}`,'Cache-Control':'private, no-store'});
          res.end(req.method==='HEAD'?undefined:body);return;
        }
        if(fileItem&&req.method==='PATCH') {
          const row=db.prepare('SELECT * FROM files WHERE owner_id=? AND id=?').get(auth.user_id,fileItem[1]);
          if(!row)return error(res,404,'file_not_found','الملف غير موجود.');
          const body=await readJson(req,16*1024);let filename=row.filename,favorite=Boolean(row.favorite),folderId=row.folder_id||null,subjectId=row.subject_id||null;
          if(Object.hasOwn(body,'name')){
            const next=sanitizeLocalFileName(body.name);
            if(!next||next==='file'||path.extname(next).toLowerCase()!==path.extname(row.filename).toLowerCase())return error(res,400,'invalid_filename','اسم الملف غير صالح؛ يجب الحفاظ على امتداده الأصلي.');
            filename=next;
          }
          if(Object.hasOwn(body,'favorite')){if(typeof body.favorite!=='boolean')return error(res,400,'invalid_favorite','قيمة المفضلة غير صالحة.');favorite=body.favorite;}
          if(Object.hasOwn(body,'subjectId')){subjectId=safeId(body.subjectId)?body.subjectId:null;if(subjectId&&!db.prepare('SELECT id FROM subjects WHERE owner_id=? AND id=?').get(auth.user_id,subjectId))return error(res,400,'invalid_subject','المادة المحددة غير موجودة.');}
          if(Object.hasOwn(body,'folderId')){folderId=safeId(body.folderId)?body.folderId:null;if(folderId){const state=db.prepare('SELECT state_json FROM learning_state WHERE user_id=?').get(auth.user_id);let folders=[];try{folders=JSON.parse(state?.state_json||'{}').folders||[]}catch{}if(!folders.some(folder=>folder.id===folderId))return error(res,400,'invalid_folder','المجلد المحدد غير موجود.');}}
          db.prepare('UPDATE files SET filename=?,favorite=?,folder_id=?,subject_id=?,updated_at=? WHERE owner_id=? AND id=?').run(filename,favorite?1:0,folderId,subjectId,new Date().toISOString(),auth.user_id,row.id);
          audit(db,auth.user_id,'file.update','file',row.id,'success');return json(res,200,{file:safeFileRow(db.prepare('SELECT * FROM files WHERE owner_id=? AND id=?').get(auth.user_id,row.id))});
        }
        if(fileItem&&req.method==='DELETE') {
          const row=db.prepare('SELECT * FROM files WHERE owner_id=? AND id=?').get(auth.user_id,fileItem[1]);
          if(!row)return error(res,404,'file_not_found','الملف غير موجود.');
          db.prepare('DELETE FROM files WHERE owner_id=? AND id=?').run(auth.user_id,row.id);
          await unlink(privateFilePath(dataDir,auth.user_id,row.id)).catch(()=>{});audit(db,auth.user_id,'file.delete','file',row.id,'success');return json(res,200,{ok:true});
        }
        if(pathname==='/api/ai/ask'&&req.method==='POST') {
          if(!rateLimit(rateLimits,`ai:${auth.user_id}`,10,60*1000))return error(res,429,'ai_rate_limited','أرسلت أسئلة كثيرة في وقت قصير. حاول بعد قليل.');
          if(!rateLimit(rateLimits,`ai-ip:${requestIp(req)}`,40,60*60*1000))return error(res,429,'ai_ip_limit','وصل اتصالك إلى الحد المؤقت للمساعد.');
          const day=new Date();day.setUTCHours(0,0,0,0);
          const count=db.prepare('SELECT COUNT(*) n FROM ai_usage WHERE owner_id=? AND created_at>=?').get(auth.user_id,day.toISOString()).n;
          if(count>=40)return error(res,429,'ai_daily_limit','وصلت إلى الحد اليومي المؤقت للمساعد.');
          const total=db.prepare('SELECT COUNT(*) n FROM ai_usage WHERE created_at>=?').get(day.toISOString()).n;
          if(total>=Number(process.env.MIDAD_AI_DAILY_GLOBAL_LIMIT||120))return error(res,503,'ai_global_limit','تجاوز الاستخدام اليومي المجاني المؤقت للخادم.');
          const body=await readJson(req,24*1024);
          try { const result=await answerMidadAI(db,auth.user_id,body);return json(res,200,result); }
          catch(e) {
            const known={ai_not_configured:[503,'ai_unavailable'],provider_not_supported:[503,'provider_unavailable'],question_too_short:[400,'question_too_short'],file_not_found:[404,'file_not_found'],ai_invalid_response:[502,'ai_invalid_response']};
            const mapped=known[e.message];
            if(mapped)return error(res,mapped[0],mapped[1],mapped[0]===400?'اكتب سؤالًا أوضح.':mapped[0]===404?'الملف غير موجود أو لا تملك صلاحية الوصول إليه.':'مساعد الذكاء الاصطناعي غير متصل حاليًا. حاول مرة أخرى.');
            return error(res,503,'ai_unavailable','مساعد الذكاء الاصطناعي غير متصل حاليًا. حاول مرة أخرى.');
          }
        }
        if(pathname==='/api/admin/overview'&&req.method==='GET') {
          if(auth.role!=='admin')return error(res,403,'forbidden','لا تملك صلاحية الإدارة.');
          return json(res,200,{users:db.prepare('SELECT COUNT(*) n FROM users').get().n,files:db.prepare('SELECT COUNT(*) n FROM files').get().n,aiRequests:db.prepare('SELECT COUNT(*) n FROM ai_usage').get().n});
        }
        return error(res,404,'not_found','المسار غير موجود.');
      } catch(e) {
        if(e.status)return error(res,e.status,e.message==='body_too_large'?'request_too_large':'invalid_request','حجم الطلب غير صالح أو يتجاوز الحد.');
        return error(res,500,'server_error','حدث خطأ داخلي؛ لم تُسجّل بيانات الاعتماد أو محتوى الملفات في السجلات.');
      }
    }
    if(req.method!=='GET'&&req.method!=='HEAD'){res.writeHead(405,{Allow:'GET, HEAD'});res.end();return;}
    const served=await serveStatic(req,res,pathname);
    if(!served)error(res,404,'not_found','المسار غير موجود.');
  });
  server.on('close',()=>{try{db.close()}catch{}});
  server.midadDb=db;
  return server;
}

if (process.argv[1] && path.resolve(process.argv[1])===fileURLToPath(import.meta.url)) {
  const port=Number(process.env.PORT||4173);const host=process.env.HOST||'0.0.0.0';
  const server=createMidadServer();
  server.listen(port,host,()=>console.log(`MIDAD full-stack server listening on http://${host}:${port}`));
}
