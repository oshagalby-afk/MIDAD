const NCBI = 'https://eutils.ncbi.nlm.nih.gov/entrez/eutils/';
const EUROPE_PMC = 'https://www.ebi.ac.uk/europepmc/webservices/rest/search';
const USER_AGENT = 'MIDAD-Learning-Assistant/1.0 (scientific literature retrieval)';

function cleanText(value = '') {
  return String(value)
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1')
    .replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"').replace(/&apos;|&#39;/g, "'")
    .replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(Number(n)))
    .replace(/&#x([\da-f]+);/gi, (_, n) => String.fromCodePoint(parseInt(n, 16)))
    .replace(/<[^>]+>/g, ' ')
    .replace(/\s+/g, ' ').trim();
}

async function getJson(url, timeout = 12000) {
  const response = await fetch(url, { headers: { 'User-Agent': USER_AGENT, 'Accept': 'application/json' }, signal: AbortSignal.timeout(timeout) });
  if (!response.ok) throw new Error(`research_http_${response.status}`);
  return response.json();
}

async function getText(url, timeout = 12000) {
  const response = await fetch(url, { headers: { 'User-Agent': USER_AGENT, 'Accept': 'application/xml,text/xml' }, signal: AbortSignal.timeout(timeout) });
  if (!response.ok) throw new Error(`research_http_${response.status}`);
  return response.text();
}

function xmlTag(block, tag) {
  const escaped = tag.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  return [...block.matchAll(new RegExp(`<${escaped}(?:\\s[^>]*)?>([\\s\\S]*?)<\\/${escaped}>`, 'gi'))].map(x => cleanText(x[1])).filter(Boolean);
}

function parsePubMedXml(xml) {
  const records = [];
  const articles = xml.match(/<PubmedArticle\b[\s\S]*?<\/PubmedArticle>/gi) || [];
  for (const block of articles) {
    const pmid = xmlTag(block, 'PMID')[0] || '';
    const title = xmlTag(block, 'ArticleTitle')[0] || '';
    const abstract = xmlTag(block, 'AbstractText').join(' ');
    const publicationTypes = xmlTag(block, 'PublicationType');
    if (publicationTypes.some(type => /preprint/i.test(type))) continue;
    const journal = xmlTag(block, 'Title')[0] || '';
    const authors = [...block.matchAll(/<Author\b[\s\S]*?<\/Author>/gi)].slice(0, 6).map(m => {
      const parts = [...xmlTag(m[0], 'ForeName'), ...xmlTag(m[0], 'LastName')];
      return parts.join(' ');
    }).filter(Boolean).join(', ');
    const year = xmlTag(block, 'Year')[0] || xmlTag(block, 'MedlineDate')[0]?.match(/\d{4}/)?.[0] || '';
    const doiMatch = block.match(/<ArticleId[^>]*IdType=["']doi["'][^>]*>([\s\S]*?)<\/ArticleId>/i);
    const doi = cleanText(doiMatch?.[1] || '');
    if (!pmid || !title) continue;
    records.push({
      id: pmid, key: doi ? `doi:${doi.toLowerCase()}` : `pmid:${pmid}`,
      sourceType: 'PubMed', title, abstract, authors, journal,
      year: String(year), doi, pmid,
      url: `https://pubmed.ncbi.nlm.nih.gov/${encodeURIComponent(pmid)}/`,
      publicationTypes,
      evidenceNote: 'PubMed journal record; verify publication type and study limitations in the linked record.',
    });
  }
  return records;
}

async function searchPubMed(query, max = 6) {
  const search = new URL('esearch.fcgi', NCBI);
  search.search = new URLSearchParams({ db: 'pubmed', term: `${query} AND journal article[Publication Type]`, retmode: 'json', retmax: String(max), sort: 'relevance' }).toString();
  const found = await getJson(search.toString());
  const ids = found?.esearchresult?.idlist || [];
  if (!ids.length) return [];
  const fetchUrl = new URL('efetch.fcgi', NCBI);
  fetchUrl.search = new URLSearchParams({ db: 'pubmed', id: ids.join(','), retmode: 'xml' }).toString();
  return parsePubMedXml(await getText(fetchUrl.toString()));
}

async function searchEuropePMC(query, max = 8) {
  const url = new URL(EUROPE_PMC);
  url.search = new URLSearchParams({ query, format: 'json', pageSize: String(max), resultType: 'core' }).toString();
  const data = await getJson(url.toString());
  return (data?.resultList?.result || []).filter(x => x.title && x.source !== 'PPR' && !(x.pubTypeList?.pubType||[]).some(type=>/preprint/i.test(type))).map(x => {
    const pmid = String(x.pmid || '');
    const doi = String(x.doi || '');
    const pmcid = String(x.pmcid || '');
    const key = doi ? `doi:${doi.toLowerCase()}` : pmid ? `pmid:${pmid}` : pmcid ? `pmcid:${pmcid}` : `epmc:${x.id || x.title}`;
    const url = pmid ? `https://pubmed.ncbi.nlm.nih.gov/${encodeURIComponent(pmid)}/` :
      pmcid ? `https://europepmc.org/articles/${encodeURIComponent(pmcid)}` :
      doi ? `https://doi.org/${encodeURIComponent(doi)}` :
      `https://europepmc.org/article/${encodeURIComponent(x.source || 'MED')}/${encodeURIComponent(x.id || '')}`;
    return {
      id: String(x.id || pmid || pmcid || key), key, sourceType: 'Europe PMC',
      title: cleanText(x.title), abstract: cleanText(x.abstractText || ''),
      authors: cleanText(x.authorString || ''), journal: cleanText(x.journalTitle || x.journalInfo?.journal?.title || ''),
      year: String(x.pubYear || ''), doi, pmid, pmcid, url,
      isOpenAccess: String(x.isOpenAccess || '').toLowerCase() === 'y',
      publicationTypes: Array.isArray(x.pubTypeList?.pubType) ? x.pubTypeList.pubType : [],
      evidenceNote: 'Europe PMC metadata and abstract; the linked article is the authoritative record.',
    };
  });
}

async function fetchOpenAccessFullText(source) {
  const pmcid=String(source.pmcid||'');
  if(!source.isOpenAccess||!/^PMC\d+$/.test(pmcid))return '';
  const xml=await getText(`https://www.ebi.ac.uk/europepmc/webservices/rest/${encodeURIComponent(pmcid)}/fullTextXML`,16000);
  const body=xml.match(/<body\b[^>]*>([\s\S]*?)<\/body>/i)?.[1]||'';
  if(!body)return '';
  return [...body.matchAll(/<p\b[^>]*>([\s\S]*?)<\/p>/gi)].map(match=>cleanText(match[1])).filter(text=>text.length>80).join('\n').slice(0,36000);
}

function rankRelevantSources(sources, query) {
  const stop=new Set('and or not with from into using about review overview mechanism mechanisms process processes pathway pathways study studies article articles journal'.split(' '));
  const terms=[...new Set(String(query).toLowerCase().replace(/[^\p{L}\p{N}\s-]/gu,' ').split(/\s+/).filter(word=>word.length>3&&!stop.has(word)))].slice(0,10);
  if(!terms.length)return sources;
  const ranked=sources.map(source=>{
    const title=cleanText(source.title||'').toLowerCase();
    const body=`${title} ${cleanText(source.abstract||'').toLowerCase()}`;
    const hit=term=>body.includes(term)||(term.length>5&&body.includes(term.slice(0,-1)));
    const titleHit=term=>title.includes(term)||(term.length>5&&title.includes(term.slice(0,-1)));
    const matches=terms.filter(hit);
    const score=matches.length+matches.filter(titleHit).length*2;
    return {...source,_relevance:score,_matchedTerms:matches.length};
  }).sort((a,b)=>b._relevance-a._relevance||String(b.year).localeCompare(String(a.year)));
  const minimum=terms.length>1?2:1;
  const relevant=ranked.filter(source=>source._matchedTerms>=minimum);
  return (relevant.length?relevant:ranked.filter(source=>source._matchedTerms>0)).map(({_relevance,_matchedTerms,...source})=>source);
}

export async function searchScientificSources(query, { maxResults = 8 } = {}) {
  const q = String(query || '').trim().slice(0, 500);
  if (q.length < 2) return { query: q, sources: [], warnings: ['query_too_short'] };
  const [europe, pubmed] = await Promise.allSettled([
    searchEuropePMC(q, Math.min(10, maxResults)),
    searchPubMed(q, Math.min(6, maxResults)),
  ]);
  const warnings = [];
  if (europe.status === 'rejected') warnings.push('europe_pmc_unavailable');
  if (pubmed.status === 'rejected') warnings.push('pubmed_unavailable');
  const merged = [];
  const byKey = new Map();
  for (const source of [...(europe.status === 'fulfilled' ? europe.value : []), ...(pubmed.status === 'fulfilled' ? pubmed.value : [])]) {
    if (!source.title) continue;
    const existing=byKey.get(source.key);
    if(existing){
      existing.indexedBy=[...new Set([...(existing.indexedBy||[existing.sourceType]),source.sourceType])];
      if(existing.indexedBy.includes('PubMed')&&existing.indexedBy.includes('Europe PMC'))existing.sourceType='PubMed + Europe PMC';
      if(source.sourceType==='PubMed'){existing.pubmedUrl=source.url;existing.url=source.url;}
      if(!existing.abstract&&source.abstract)existing.abstract=source.abstract;
      continue;
    }
    const item={...source,id:source.key,indexedBy:[source.sourceType]};byKey.set(source.key,item);merged.push(item);
  }
  const ranked=rankRelevantSources(merged,q);
  if(merged.length&&!ranked.length)warnings.push('no_relevant_scientific_records');
  const openAccess=ranked.filter(source=>source.isOpenAccess&&/^PMC\d+$/.test(String(source.pmcid||''))).slice(0,4);
  const fullTextResults=await Promise.allSettled(openAccess.map(source=>fetchOpenAccessFullText(source)));
  fullTextResults.forEach((result,index)=>{if(result.status==='fulfilled'&&result.value)openAccess[index].fullText=result.value;});
  if(openAccess.length&&fullTextResults.every(result=>result.status==='rejected'))warnings.push('open_access_full_text_unavailable');
  return { query: q, sources: ranked.slice(0, maxResults), warnings };
}
