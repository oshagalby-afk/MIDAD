import test from 'node:test';
import assert from 'node:assert/strict';
import os from 'node:os';
import path from 'node:path';
import fs from 'node:fs';
import { openDatabase } from './database.mjs';
import { answerMidadAI } from './ai-service.mjs';

test('AI conversation context is owner-scoped and does not replace current evidence',async t=>{
  const dataDir=fs.mkdtempSync(path.join(os.tmpdir(),'midad-ai-context-'));
  const db=openDatabase(dataDir);
  t.after(()=>{db.close();fs.rmSync(dataDir,{recursive:true,force:true});});
  const now='2026-10-08T00:00:00.000Z',owner='student-one',other='student-two',conversationId='history-thread',fileId='lesson-file';
  const addUser=db.prepare('INSERT INTO users(id,email,password_hash,role,created_at) VALUES(?,?,?,?,?)');
  addUser.run(owner,'student-one@example.invalid','test-hash','student',now);
  addUser.run(other,'student-two@example.invalid','test-hash','student',now);
  db.prepare(`INSERT INTO files(owner_id,id,filename,media_type,size_bytes,status,storage_key,preview_kind,created_at,updated_at)
    VALUES(?,?,?,'text/plain',10,'ready',?,'download',?,?)`).run(owner,fileId,'lesson.txt','lesson-file.bin',now,now);
  const evidence='The lecture explains that mitochondria produce ATP through oxidative phosphorylation. '.repeat(30);
  db.prepare('INSERT INTO file_chunks(owner_id,file_id,chunk_no,page_no,section,content) VALUES(?,?,1,2,?,?)').run(owner,fileId,'Lecture 4',evidence);
  const addConversation=db.prepare('INSERT INTO ai_conversations(owner_id,id,title,context_file_id,created_at,updated_at) VALUES(?,?,?,?,?,?)');
  addConversation.run(owner,conversationId,'ATP',fileId,now,now);
  addConversation.run(other,conversationId,'private',fileId,now,now);
  const addMessage=db.prepare('INSERT INTO ai_messages(owner_id,id,conversation_id,role,content,evidence_level,created_at) VALUES(?,?,?,?,?,?,?)');
  addMessage.run(owner,'old-user',conversationId,'user','Earlier, I asked which process this lecture describes.',null,'2026-10-08T00:00:00.100Z');
  addMessage.run(owner,'old-assistant',conversationId,'assistant','It describes a cellular energy process.','limited','2026-10-08T00:00:00.101Z');
  addMessage.run(other,'foreign-user',conversationId,'user','SECRET_FROM_ANOTHER_ACCOUNT',null,'2026-10-08T00:00:00.100Z');

  let captured=[];
  const answer=await answerMidadAI(db,owner,{prompt:'What do mitochondria produce through oxidative phosphorylation?',locale:'en',fileId,conversationId},{
    complete:async request=>{
      captured=request.messages;
      return {content:JSON.stringify({answer:'The lecture states that mitochondria produce ATP through oxidative phosphorylation.',evidence_level:'moderate',limitations:'',citations:['F1'],insufficient:false}),model:'unit-test',usage:{inputTokens:24,outputTokens:18}};
    },
    scientificSearch:async()=>{throw new Error('scientific search must not run for strong file evidence');},
  });
  assert.equal(answer.conversationId,conversationId);
  assert.ok(captured.some(message=>message.role==='user'&&message.content.includes('Earlier, I asked')));
  assert.ok(captured.some(message=>message.role==='assistant'&&message.content.includes('cellular energy process')));
  assert.ok(captured.find(message=>message.role==='system').content.includes('current supplied evidence'));
  assert.ok(!captured.some(message=>message.content.includes('SECRET_FROM_ANOTHER_ACCOUNT')));
  assert.equal(db.prepare('SELECT COUNT(*) n FROM ai_messages WHERE owner_id=? AND conversation_id=?').get(owner,conversationId).n,4);
});
