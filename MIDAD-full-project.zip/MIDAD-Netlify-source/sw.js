const CACHE = 'midad-public-shell-v11';
const SHELL = ['/', '/index.html', '/styles.css', '/bootstrap.mjs', '/app.js', '/file-policy.mjs', '/icon.svg', '/manifest.webmanifest', '/sw.js'];
const ALLOWED_STATIC = new Set(SHELL);
self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(SHELL)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key.startsWith('midad-') && key !== CACHE).map(key => caches.delete(key)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', event => {
  const request = event.request;
  const url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== self.location.origin) return;
  // User data, APIs, dynamic paths and unknown resources are never cached.
  if (url.pathname.startsWith('/api/') || !ALLOWED_STATIC.has(url.pathname)) return;
  // Ignore query strings only for these fixed public shell paths so versioned assets also work offline.
  const cacheRequest = new Request(`${url.origin}${url.pathname}`, { method: 'GET' });
  event.respondWith(caches.open(CACHE).then(async cache => {
    const cached = await cache.match(cacheRequest);
    if (cached) return cached;
    try {
      const response = await fetch(request);
      if (response.ok && response.type === 'basic') await cache.put(cacheRequest, response.clone());
      return response;
    } catch {
      return (await cache.match('/index.html')) || new Response('Offline', { status: 503, headers: { 'Content-Type': 'text/plain; charset=utf-8' } });
    }
  }));
});
